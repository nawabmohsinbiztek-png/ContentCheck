import { useState, useEffect, useMemo, useRef, useCallback } from "react";
import Papa from "papaparse";
import * as XLSX from "xlsx";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from "recharts";
import { Upload, AlertTriangle, ExternalLink, Search, X, Check, Plus, Download, Trash2 } from "lucide-react";

/* ============================================================
   Content Performance Hub — Print247 & CustomMylarBags
   Data comes from exports (GSC, Ahrefs, Semrush). Writers only
   claim pages. Everything is stored in shared artifact storage.
   ============================================================ */

// ---------- palette (print process colors on paper) ----------
const C = {
  paper: "#F6F7F4", card: "#FFFFFF", ink: "#1C2126", muted: "#6B7178", rule: "#D9DCD5",
  soft: "#EEF0EC", cyan: "#0098C8", mag: "#C8246B", yel: "#E0A100", up: "#0A7F5A", down: "#C8246B",
};
const SERIES = ["#0098C8", "#C8246B", "#E0A100", "#1C2126", "#0A7F5A", "#7A5AC8", "#8A6A3D", "#5B7D8C"];
const FONT = "'Archivo', 'Helvetica Neue', Arial, sans-serif";
const NUM = { fontVariantNumeric: "tabular-nums" };

// ---------- constants ----------
const K = { cfg: "cph:cfg", reg: "cph:register", log: "cph:log" };
const INDEX_STATUSES = ["Indexed", "Crawled – Not Indexed", "Discovered – Not Indexed", "Excluded / Noindex", "Redirect / 404"];
const DEFAULT_CFG = {
  writers: ["Mohsin", "Fizza", "Hassan", "Maryam"],
  types: ["On-Page Blog", "Off-Page Blog", "Product Description", "Industry Page", "Knowledge Base", "PPC Landing Page"],
  domains: { "print247.us": "Print247", "custommylarbags.com": "CustomMylarBags" },
};
const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

// ---------- small utils ----------
const pad = (n) => String(n).padStart(2, "0");
const isoUTC = (d) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
const localISO = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const TODAY = localISO();
const md = (s) => (s ? `${s.slice(5, 7)}/${s.slice(8, 10)}` : "");
const usDate = (s) => (s ? `${s.slice(5, 7)}/${s.slice(8, 10)}/${s.slice(0, 4)}` : "");
const addDaysISO = (s, n) => { const d = new Date(s + "T00:00:00Z"); d.setUTCDate(d.getUTCDate() + n); return isoUTC(d); };
const daysBetween = (a, b) => Math.round((new Date(b + "T00:00:00Z") - new Date(a + "T00:00:00Z")) / 86400000);
const fmtInt = (n) => (n === null || n === undefined || n === "" ? "–" : Math.round(n).toLocaleString("en-US"));
const fmtPct = (n, d = 0) => (n === null || n === undefined || !isFinite(n) ? "–" : (n * 100).toFixed(d) + "%");
const fmtPos = (n) => (n === null || n === undefined || !isFinite(n) ? "–" : n.toFixed(1));
const num = (v) => {
  if (v === null || v === undefined || v === "") return 0;
  if (typeof v === "number") return isFinite(v) ? v : 0;
  const n = parseFloat(String(v).replace(/[,%\s]/g, ""));
  return isNaN(n) ? 0 : n;
};
const normKey = (u) => {
  if (!u) return "";
  let s = String(u).trim().toLowerCase();
  s = s.replace(/^https?:\/\//, "").replace(/^www\./, "");
  s = s.split("#")[0].split("?")[0].replace(/\/+$/, "");
  return s;
};
const hostOf = (key) => key.split("/")[0];
const pathOf = (key) => { const i = key.indexOf("/"); return i < 0 ? "/" : key.slice(i); };
const toISO = (v) => {
  if (v === null || v === undefined || v === "") return "";
  if (typeof v === "number") return v > 20000 ? isoUTC(new Date(Math.round((v - 25569) * 86400000))) : "";
  const s = String(v).trim();
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return `${m[1]}-${pad(m[2])}-${pad(m[3])}`;
  m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/);
  if (m) return `${m[3].length === 2 ? "20" + m[3] : m[3]}-${pad(m[1])}-${pad(m[2])}`;
  const d = new Date(s);
  return isNaN(d) ? "" : localISO(d);
};

// ---------- calendar: Wednesday-to-Wednesday cycles, 4 per month ----------
function buildCalendar() {
  const weeks = [], months = [];
  for (let y = 2025; y <= 2027; y++) {
    for (let m = 0; m < 12; m++) {
      const first = new Date(Date.UTC(y, m, 1)), last = new Date(Date.UTC(y, m + 1, 0));
      const weds = [];
      for (let d = 1; d <= last.getUTCDate(); d++) if (new Date(Date.UTC(y, m, d)).getUTCDay() === 3) weds.push(new Date(Date.UTC(y, m, d)));
      const ends = weds.length === 5 ? [weds[1], weds[2], weds[3], last] : [weds[0], weds[1], weds[2], last];
      const mid = `${y}-${pad(m + 1)}`;
      let s = isoUTC(first);
      const ids = [];
      ends.forEach((e, i) => {
        const id = `${MON[m]}${String(y).slice(2)}-W${i + 1}`;
        weeks.push({ type: "W", id, month: mid, start: s, end: isoUTC(e), label: `${id}  (${md(s)}–${md(isoUTC(e))})` });
        ids.push(id);
        s = addDaysISO(isoUTC(e), 1);
      });
      months.push({ type: "M", id: mid, start: isoUTC(first), end: isoUTC(last), label: `${MON[m]} ${y}`, weeks: ids });
    }
  }
  return { weeks, months };
}
const CAL = buildCalendar();
const WEEK_BY_ID = Object.fromEntries(CAL.weeks.map((w) => [w.id, w]));
const MONTH_BY_ID = Object.fromEntries(CAL.months.map((m) => [m.id, m]));
const CUR_WEEK_IDX = Math.max(0, CAL.weeks.findIndex((w) => w.start <= TODAY && w.end >= TODAY));
const CUR_MONTH_IDX = Math.max(0, CAL.months.findIndex((m) => m.start <= TODAY && m.end >= TODAY));
const periodList = (type) => (type === "W" ? CAL.weeks : CAL.months);
const getPeriod = (type, id) => (type === "W" ? WEEK_BY_ID[id] : MONTH_BY_ID[id]);
const prevPeriod = (p) => { const L = periodList(p.type); const i = L.findIndex((x) => x.id === p.id); return i > 0 ? L[i - 1] : null; };
const lastCompleted = (type) => (type === "W" ? CAL.weeks[Math.max(0, CUR_WEEK_IDX - 1)] : CAL.months[Math.max(0, CUR_MONTH_IDX - 1)]);

// ---------- storage (shared across everyone using this artifact) ----------
let MODE = "live";
const demoMem = {};
const memFallback = {};
const S = {
  async get(k) {
    if (MODE === "demo") return demoMem[k] ?? null;
    try {
      if (!window.storage) return memFallback[k] ?? null;
      const r = await window.storage.get(k, true);
      return r && r.value ? JSON.parse(r.value) : null;
    } catch (e) { return null; }
  },
  async set(k, v) {
    if (MODE === "demo") { demoMem[k] = v; return true; }
    const s = JSON.stringify(v);
    if (s.length > 4900000) throw new Error("This data is over the 5 MB storage limit. Filter the export (e.g. US only, positions 1–100) and try again.");
    if (!window.storage) { memFallback[k] = v; return true; }
    const r = await window.storage.set(k, s, true);
    if (!r) throw new Error("Storage refused the write. Try again in a moment.");
    return true;
  },
  async del(k) {
    if (MODE === "demo") { delete demoMem[k]; return; }
    try { if (!window.storage) { delete memFallback[k]; return; } await window.storage.delete(k, true); } catch (e) { /* key already gone */ }
  },
  async list(prefix) {
    let keys = [];
    if (MODE === "demo") keys = Object.keys(demoMem);
    else {
      try {
        if (!window.storage) keys = Object.keys(memFallback);
        else { const r = await window.storage.list(prefix, true); keys = (r && r.keys) || []; }
      } catch (e) { keys = []; }
    }
    return keys.map((k) => (typeof k === "string" ? k : k.key)).filter((k) => k && k.startsWith(prefix));
  },
};
const gscKey = (type, id) => `cph:gsc:${type}:${id}`;
const rankKey = (id) => `cph:rank:${id}`;
const idxKey = (id) => `cph:idx:${id}`;

// ---------- file reading & detection ----------
function decodeText(buf) {
  const b = new Uint8Array(buf);
  if (b[0] === 0xff && b[1] === 0xfe) return new TextDecoder("utf-16le").decode(b.subarray(2));
  if (b[0] === 0xfe && b[1] === 0xff) return new TextDecoder("utf-16be").decode(b.subarray(2));
  let zeros = 0, n = 0;
  for (let i = 1; i < Math.min(b.length, 4000); i += 2) { n++; if (b[i] === 0) zeros++; }
  if (n > 10 && zeros / n > 0.3) return new TextDecoder("utf-16le").decode(b).replace(/\u0000/g, "");
  let t = new TextDecoder("utf-8").decode(b);
  if (t.charCodeAt(0) === 0xfeff) t = t.slice(1);
  return t.replace(/\u0000/g, "");
}
const H_N = (s) => String(s ?? "").replace(/^\uFEFF/, "").trim().toLowerCase().replace(/\s+/g, " ");

function analyze(rows) {
  for (let h = 0; h < Math.min(10, rows.length); h++) {
    const H = (rows[h] || []).map(H_N);
    const find = (...ns) => { for (const n of ns) { const i = H.indexOf(n); if (i >= 0) return i; } return -1; };
    const kw = find("keyword"), clicks = find("clicks", "url clicks"), impr = find("impressions");
    const page = find("top pages", "page", "pages", "landing page", "landing pages", "url", "address");
    if (clicks >= 0 && impr >= 0 && page >= 0 && kw < 0)
      return { type: "gsc", h, cols: { page, clicks, impr, pos: find("position", "average position", "avg. position") } };
    if (kw >= 0) {
      const pos = find("current position", "position", "pos.", "pos");
      const url = find("current url", "url", "ranking url", "landing page");
      if (pos >= 0 && url >= 0) {
        const semrush = H.includes("search volume") || H.includes("keyword difficulty");
        return { type: "ranks", h, source: semrush ? "Semrush" : "Ahrefs", cols: {
          kw, pos, url, vol: find("volume", "search volume", "current volume"),
          kd: find("kd", "keyword difficulty", "difficulty"),
          tr: find("organic traffic", "current organic traffic", "traffic", "current traffic") } };
      }
    }
    if (find("top queries", "query", "queries") >= 0 && clicks >= 0) return { type: "gscQueries", h };
    const url = find("url", "page", "address", "loc", "urls", "live url");
    if (url >= 0 && find("writer", "author") >= 0)
      return { type: "mapping", h, cols: { url, writer: find("writer", "author"), ctype: find("type", "content type"),
        title: find("title", "title / h1", "h1"), pub: find("publish date", "published", "date published", "publish"),
        pk: find("primary keyword", "focus keyword", "keyword") } };
    if (url >= 0 && find("last crawled", "last crawl") >= 0) return { type: "index", h, cols: { url } };
    if (url >= 0) return { type: "urls", h, cols: { url } };
  }
  if (rows.length && /^https?:\/\//i.test(String(rows[0][0] || ""))) return { type: "urls", h: -1, cols: { url: 0 } };
  return null;
}
const PRIORITY = ["gsc", "ranks", "mapping", "index", "urls", "gscQueries"];

async function readAny(file) {
  const buf = await file.arrayBuffer();
  const name = file.name.toLowerCase();
  let candidates = [];
  if (/\.(xlsx|xls|xlsm)$/.test(name)) {
    const wb = XLSX.read(buf, { type: "array" });
    for (const sn of wb.SheetNames) {
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[sn], { header: 1, raw: true, defval: "" });
      const a = analyze(rows);
      if (a) candidates.push({ ...a, rows, sheet: sn });
    }
  } else {
    const text = decodeText(buf);
    const parsed = Papa.parse(text, { skipEmptyLines: true });
    const a = analyze(parsed.data);
    if (a) candidates.push({ ...a, rows: parsed.data, sheet: null });
  }
  candidates.sort((x, y) => PRIORITY.indexOf(x.type) - PRIORITY.indexOf(y.type));
  return candidates[0] || null;
}

function parseDetected(det) {
  const body = det.rows.slice(det.h + 1);
  const c = det.cols || {};
  if (det.type === "gsc") {
    const map = {};
    let rows = 0, clicks = 0, impr = 0;
    for (const r of body) {
      const key = normKey(r[c.page]); if (!key || !key.includes(".")) continue;
      const cl = num(r[c.clicks]), im = num(r[c.impr]), po = c.pos >= 0 ? num(r[c.pos]) : 0;
      const e = map[key] || (map[key] = [0, 0, 0]);
      e[0] += cl; e[1] += im; e[2] += po * im; rows++; clicks += cl; impr += im;
    }
    return { data: map, summary: `${rows.toLocaleString()} pages · ${fmtInt(clicks)} clicks · ${fmtInt(impr)} impressions` };
  }
  if (det.type === "ranks") {
    const pages = {};
    let rows = 0;
    for (const r of body) {
      const kw = String(r[c.kw] ?? "").trim(); const pos = num(r[c.pos]); const key = normKey(r[c.url]);
      if (!kw || !key || pos <= 0) continue;
      const vol = c.vol >= 0 ? num(r[c.vol]) : 0, kd = c.kd >= 0 ? num(r[c.kd]) : 0, tr = c.tr >= 0 ? num(r[c.tr]) : 0;
      const p = pages[key] || (pages[key] = { n: 0, t3: 0, t10: 0, t20: 0, tr: 0, kws: [] });
      p.n++; if (pos <= 3) p.t3++; if (pos <= 10) p.t10++; if (pos <= 20) p.t20++; p.tr += tr;
      p.kws.push([kw, pos, vol, kd, Math.round(tr)]);
      rows++;
    }
    return { data: pages, summary: `${rows.toLocaleString()} keyword rankings across ${Object.keys(pages).length.toLocaleString()} URLs (${det.source})` };
  }
  if (det.type === "index" || det.type === "urls") {
    const urls = [];
    for (const r of body) { const u = String(r[c.url] ?? "").trim(); if (/^https?:\/\//i.test(u) || u.includes(".")) urls.push(u); }
    return { data: urls, summary: `${urls.length.toLocaleString()} URLs` };
  }
  if (det.type === "mapping") {
    const items = [];
    for (const r of body) {
      const u = String(r[c.url] ?? "").trim(); if (!u) continue;
      items.push({ url: u, writer: String(r[c.writer] ?? "").trim(), type: c.ctype >= 0 ? String(r[c.ctype] ?? "").trim() : "",
        title: c.title >= 0 ? String(r[c.title] ?? "").trim() : "", pub: c.pub >= 0 ? toISO(r[c.pub]) : "",
        pk: c.pk >= 0 ? String(r[c.pk] ?? "").trim() : "" });
    }
    return { data: items, summary: `${items.length.toLocaleString()} rows with writer names` };
  }
  return { data: null, summary: "" };
}

// trim rank snapshot to keep storage small; keep primary keywords
function trimRanks(pages, register) {
  const out = {};
  for (const [key, p] of Object.entries(pages)) {
    const pk = (register[key]?.pk || "").toLowerCase();
    const sorted = [...p.kws].sort((a, b) => b[4] - a[4] || b[2] - a[2] || a[1] - b[1]);
    let keep = sorted.slice(0, 15);
    if (pk && !keep.some((k) => k[0].toLowerCase() === pk)) {
      const hit = sorted.find((k) => k[0].toLowerCase() === pk);
      if (hit) keep.push(hit);
    }
    out[key] = { n: p.n, t3: p.t3, t10: p.t10, t20: p.t20, tr: Math.round(p.tr), kws: keep };
  }
  return out;
}

// ---------- metrics ----------
function snapIn(period, rankIds) {
  if (!period) return null;
  const inside = CAL.weeks.filter((w) => w.start >= period.start && w.end <= period.end && rankIds.has(w.id));
  return inside.length ? inside[inside.length - 1].id : null;
}

function pageStat(key, reg, ctx, cfg) {
  const g = ctx.gsc ? ctx.gsc[key] : null, gp = ctx.gscPrev ? ctx.gscPrev[key] : null;
  const clicks = g ? g[0] : 0, impr = g ? g[1] : 0, pos = g && g[1] ? g[2] / g[1] : null;
  const pClicks = gp ? gp[0] : 0, pImpr = gp ? gp[1] : 0, pPos = gp && gp[1] ? gp[2] / gp[1] : null;
  const r = ctx.rank ? ctx.rank.pages[key] : null, rp = ctx.rankPrev ? ctx.rankPrev.pages[key] : null;
  let pk = reg.pk || "", pkAuto = false;
  if (!pk && r && r.kws.length) { pk = r.kws[0][0]; pkAuto = true; }
  const pkl = pk.toLowerCase();
  const hit = r && pk ? r.kws.find((k) => k[0].toLowerCase() === pkl) : null;
  const hitP = rp && pk ? rp.kws.find((k) => k[0].toLowerCase() === pkl) : null;
  const pkPos = hit ? hit[1] : null, pkPrev = hitP ? hitP[1] : null, pkVol = hit ? hit[2] : hitP ? hitP[2] : null;
  let idx = ctx.idxMap[key] || null, idxInferred = false;
  if (!idx && impr > 0) { idx = "Indexed"; idxInferred = true; }
  if (!idx && ctx.gscPrev && pImpr > 0) { idx = "Indexed"; idxInferred = true; }
  const project = cfg.domains[hostOf(key)] || hostOf(key);
  const alerts = [];
  const age = reg.pub ? daysBetween(reg.pub, ctx.P.end) : null;
  if (idx && idx !== "Indexed") alerts.push({ k: "idx", t: idx });
  else if (ctx.gsc && impr === 0 && (age === null || age > 21)) alerts.push({ k: "vis", t: "No Google impressions" });
  if (ctx.gscPrev && pClicks >= 10 && clicks <= pClicks * 0.7) alerts.push({ k: "drop", t: `Clicks down ${Math.round((1 - clicks / pClicks) * 100)}%` });
  if (pkPrev && pkPrev <= 10 && (!pkPos || pkPos > 10)) alerts.push({ k: "kw", t: `“${pk}” left top 10` });
  else if (pkPrev && pkPos && pkPos - pkPrev >= 5) alerts.push({ k: "kw", t: `“${pk}” down ${pkPos - pkPrev}` });
  if (!reg.writer) alerts.push({ k: "own", t: "No writer assigned" });
  return {
    key, reg, project, writer: reg.writer || "", clicks, impr, pos, pClicks, pImpr, pPos,
    dClicks: gp || g ? clicks - pClicks : null, ctr: impr ? clicks / impr : null,
    n: r ? r.n : 0, t3: r ? r.t3 : 0, t10: r ? r.t10 : 0, t20: r ? r.t20 : 0, tr: r ? r.tr : 0,
    pT10: rp ? rp.t10 : 0, hasRank: !!r,
    pk, pkAuto, pkPos, pkPrev, pkVol, idx, idxInferred, alerts,
    isNew: reg.pub && reg.pub >= ctx.P.start && reg.pub <= ctx.P.end,
  };
}

function aggregate(rows) {
  const a = { pages: rows.length, newP: 0, clicks: 0, impr: 0, pw: 0, pClicks: 0, pImpr: 0, seen: 0, t3: 0, t10: 0, t20: 0, pT10: 0, kws: 0, alerts: 0 };
  for (const s of rows) {
    a.clicks += s.clicks; a.impr += s.impr; a.pw += (s.pos || 0) * s.impr; a.pClicks += s.pClicks; a.pImpr += s.pImpr;
    if (s.impr > 0) a.seen++; if (s.isNew) a.newP++;
    a.t3 += s.t3; a.t10 += s.t10; a.t20 += s.t20; a.pT10 += s.pT10; a.kws += s.n;
    a.alerts += s.alerts.filter((x) => x.k !== "own").length;
  }
  a.ctr = a.impr ? a.clicks / a.impr : null;
  a.pos = a.impr ? a.pw / a.impr : null;
  a.dClicksPct = a.pClicks ? (a.clicks - a.pClicks) / a.pClicks : null;
  return a;
}

// ---------- sample data (in-memory only) ----------
function rng(seed) { return () => { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function makeDemo() {
  const R = rng(247);
  const writers = DEFAULT_CFG.writers;
  const topics = ["custom mailer boxes cost", "mocra labeling checklist", "rigid box vs folding carton", "custom cbd packaging", "ect vs mullen test", "food safe packaging", "custom candle boxes", "child resistant mylar bags", "cookie mylar bags", "custom pouch printing", "spot uv vs foil", "custom cosmetic boxes", "custom tuck end boxes", "kraft boxes wholesale", "custom soap boxes", "shipping box dimensions", "custom pizza boxes", "gable boxes", "custom hang tags", "window boxes", "custom sleeve packaging", "pre roll packaging", "custom tea packaging", "bakery boxes", "custom jewelry boxes", "custom apparel boxes", "headphone packaging", "electronic packaging", "pfas packaging rules", "epr packaging laws", "custom stand up pouches", "mylar bag sizes", "smell proof bags", "custom coffee bags", "vape packaging", "custom lip gloss boxes"];
  const types = ["On-Page Blog", "Knowledge Base", "Industry Page", "Product Description"];
  const register = {}, base = {};
  topics.forEach((t, i) => {
    const slug = t.replace(/\s+/g, "-");
    const cmb = /mylar|pouch|smell|coffee|bags/.test(t);
    const url = cmb ? `https://custommylarbags.com/blog/${slug}` : `https://print247.us/${i % 3 ? "post" : "knowledge"}/${slug}`;
    const key = normKey(url);
    const pubDaysAgo = i < 4 ? 5 + i * 9 : 60 + Math.floor(R() * 600);
    register[key] = { url, writer: i % 9 === 8 ? "" : writers[i % 4], type: types[i % 4], title: t.replace(/\b\w/g, (m) => m.toUpperCase()),
      pub: addDaysISO(TODAY, -pubDaysAgo), pk: i % 2 ? t : "", added: TODAY };
    base[key] = { c: Math.floor(R() * 60) + (i < 4 ? 2 : 8), trend: (R() - 0.45) * 0.12, pos: 4 + R() * 30, kw: t };
  });
  demoMem[K.cfg] = DEFAULT_CFG; demoMem[K.reg] = register;
  // weekly GSC + ranks for last 10 completed cycles, monthly GSC for last 2 months
  const wEnd = Math.max(0, CUR_WEEK_IDX - 1);
  for (let wi = wEnd - 9; wi <= wEnd; wi++) {
    const w = CAL.weeks[wi]; if (!w) continue; const step = wi - (wEnd - 9);
    const g = {}, pages = {};
    for (const [key, b] of Object.entries(base)) {
      const reg = register[key]; if (reg.pub > w.end) continue;
      const c = Math.max(0, Math.round(b.c * Math.pow(1 + b.trend, step) * (0.8 + R() * 0.4)));
      const im = Math.round(c * (25 + R() * 40)) + Math.floor(R() * 40);
      const pos = Math.max(1.5, b.pos - b.trend * step * 6 + (R() - 0.5) * 2);
      if (key.includes("custom-candle") && step > 6) { g[key] = [0, 0, 0]; continue; }
      g[key] = [c, im, pos * im];
      const kws = [];
      const kwN = 3 + Math.floor(R() * 6);
      for (let k = 0; k < kwN; k++) {
        const kp = Math.max(1, Math.round(pos + k * 4 + (R() - 0.5) * 4));
        kws.push([k === 0 ? b.kw : `${b.kw} ${["price", "near me", "wholesale", "ideas", "guide", "usa", "bulk", "design"][k % 8]}`, kp, Math.round(100 + R() * 1500), Math.round(R() * 40), Math.round(c * (k === 0 ? 0.5 : 0.1))]);
      }
      pages[key] = { n: kws.length, t3: kws.filter((k) => k[1] <= 3).length, t10: kws.filter((k) => k[1] <= 10).length, t20: kws.filter((k) => k[1] <= 20).length, tr: kws.reduce((s, k) => s + k[4], 0), kws };
    }
    demoMem[gscKey("W", w.id)] = g;
    demoMem[rankKey(w.id)] = { src: "Ahrefs", at: w.end, pages };
  }
  for (let mi = CUR_MONTH_IDX - 2; mi < CUR_MONTH_IDX; mi++) {
    const m = CAL.months[mi]; const agg = {};
    for (const wid of m.weeks) { const g = demoMem[gscKey("W", wid)]; if (!g) continue; for (const [k, v] of Object.entries(g)) { const e = agg[k] || (agg[k] = [0, 0, 0]); e[0] += v[0]; e[1] += v[1]; e[2] += v[2]; } }
    if (Object.keys(agg).length) demoMem[gscKey("M", m.id)] = agg;
  }
  const keys = Object.keys(register);
  const idx = {}; keys.forEach((k, i) => { idx[k] = i === 1 ? "Crawled – Not Indexed" : i === 2 ? "Discovered – Not Indexed" : "Indexed"; });
  demoMem[idxKey(CAL.weeks[wEnd].id)] = idx;
  demoMem[K.log] = [{ at: TODAY, what: "Sample data loaded", by: "demo" }];
}

// ============================================================
//                         UI pieces
// ============================================================
function Btn({ children, onClick, kind = "ghost", disabled, title, small }) {
  const st = kind === "primary" ? { background: C.ink, color: "#fff", border: `1px solid ${C.ink}` }
    : kind === "danger" ? { background: "#fff", color: C.down, border: `1px solid ${C.down}` }
    : { background: "#fff", color: C.ink, border: `1px solid ${C.rule}` };
  return (
    <button title={title} disabled={disabled} onClick={onClick}
      className={`${small ? "px-2 py-1 text-xs" : "px-3 py-1.5 text-sm"} rounded font-medium inline-flex items-center gap-1.5 focus:outline-none focus:ring-2 disabled:opacity-40`}
      style={st}>{children}</button>
  );
}
function Sel({ value, onChange, options, style, className = "" }) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} className={`text-sm rounded px-2 py-1.5 focus:outline-none focus:ring-2 ${className}`}
      style={{ border: `1px solid ${C.rule}`, background: "#fff", color: C.ink, ...style }}>
      {options.map((o) => (typeof o === "string" ? <option key={o} value={o}>{o}</option> : <option key={o.v} value={o.v}>{o.l}</option>))}
    </select>
  );
}
function Delta({ v, pct, invert, suffix = "" }) {
  if (v === null || v === undefined || !isFinite(v) || v === 0) return <span style={{ color: C.muted }}>–</span>;
  const good = invert ? v < 0 : v > 0;
  const txt = pct ? `${Math.abs(v * 100).toFixed(0)}%` : `${Math.abs(Math.round(v * 10) / 10).toLocaleString()}${suffix}`;
  return <span style={{ color: good ? C.up : C.down, fontWeight: 600, ...NUM }}>{v > 0 ? "▲" : "▼"} {txt}</span>;
}
function IdxBadge({ s, inferred }) {
  if (!s) return <span style={{ color: C.muted }}>Unknown</span>;
  const ok = s === "Indexed";
  return (
    <span className="text-xs px-1.5 py-0.5 rounded whitespace-nowrap" title={inferred ? "Inferred: page received Google impressions" : "From GSC indexing export"}
      style={{ background: ok ? "#E3F3EC" : "#FBE6EE", color: ok ? C.up : C.down }}>{ok ? (inferred ? "Indexed*" : "Indexed") : s}</span>
  );
}
function Modal({ title, onClose, children, width = 560 }) {
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 overflow-auto" style={{ background: "rgba(28,33,38,.45)" }} onClick={onClose}>
      <div className="rounded-lg w-full mt-10" style={{ background: "#fff", maxWidth: width }} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-3" style={{ borderBottom: `1px solid ${C.rule}` }}>
          <div className="font-semibold">{title}</div>
          <button onClick={onClose} aria-label="Close" className="p-1 rounded focus:outline-none focus:ring-2"><X size={18} /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}
function Field({ label, children, hint }) {
  return (
    <label className="block mb-3">
      <div className="text-xs font-semibold mb-1" style={{ color: C.muted }}>{label}</div>
      {children}
      {hint && <div className="text-xs mt-1" style={{ color: C.muted }}>{hint}</div>}
    </label>
  );
}
const inputStyle = { border: `1px solid ${C.rule}`, background: "#fff", color: C.ink };
function Input(props) { return <input {...props} className="w-full text-sm rounded px-2 py-1.5 focus:outline-none focus:ring-2" style={inputStyle} />; }

function downloadCSV(name, header, rows) {
  try {
    const esc = (v) => { const s = v === null || v === undefined ? "" : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
    const csv = [header, ...rows].map((r) => r.map(esc).join(",")).join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = name; document.body.appendChild(a); a.click(); a.remove();
  } catch (e) { alert("Download is blocked in this view. Open the artifact in full screen and try again."); }
}

// ---------- print-sheet color bar: which data exists per period ----------
function ColorBar({ type, manifest, selected, onPick }) {
  const L = periodList(type);
  const endIdx = type === "W" ? CUR_WEEK_IDX : CUR_MONTH_IDX;
  const slice = L.slice(Math.max(0, endIdx - (type === "W" ? 15 : 11)), endIdx + 1);
  const has = (p) => {
    const gsc = type === "W" ? manifest.gscW.has(p.id) : manifest.gscM.has(p.id);
    const inside = type === "W" ? [p.id] : p.weeks;
    return { gsc, rank: inside.some((w) => manifest.rank.has(w)), idx: inside.some((w) => manifest.idx.has(w)) };
  };
  return (
    <div className="flex items-end gap-1 overflow-x-auto pb-1" role="list" aria-label="Data available per period">
      {slice.map((p) => {
        const h = has(p), sel = p.id === selected;
        return (
          <button key={p.id} role="listitem" onClick={() => onPick(p.id)} title={`${p.label}\nGSC: ${h.gsc ? "yes" : "no"} · Ranks: ${h.rank ? "yes" : "no"} · Index: ${h.idx ? "yes" : "no"}`}
            className="flex flex-col items-center focus:outline-none focus:ring-2 rounded" style={{ minWidth: type === "W" ? 44 : 56 }}>
            <div className="w-full flex flex-col rounded-sm overflow-hidden" style={{ height: 30, outline: sel ? `2px solid ${C.ink}` : "none", outlineOffset: 1 }}>
              <div style={{ flex: 1, background: h.gsc ? C.cyan : C.soft }} />
              <div style={{ flex: 1, background: h.rank ? C.mag : C.soft }} />
              <div style={{ flex: 1, background: h.idx ? C.yel : C.soft }} />
            </div>
            <div className="text-xs mt-1 whitespace-nowrap" style={{ color: sel ? C.ink : C.muted, fontWeight: sel ? 700 : 400, fontSize: 10 }}>
              {type === "W" ? p.id.replace(/^(\w{3})\d\d-/, "$1 ") : p.label.slice(0, 3) + " " + p.label.slice(-2)}
            </div>
          </button>
        );
      })}
      <div className="ml-3 text-xs leading-5 whitespace-nowrap" style={{ color: C.muted }}>
        <div><span className="inline-block w-2.5 h-2.5 mr-1 align-middle" style={{ background: C.cyan }} />GSC clicks</div>
        <div><span className="inline-block w-2.5 h-2.5 mr-1 align-middle" style={{ background: C.mag }} />Keyword ranks</div>
        <div><span className="inline-block w-2.5 h-2.5 mr-1 align-middle" style={{ background: C.yel }} />Index check</div>
      </div>
    </div>
  );
}

function Kpi({ label, value, delta }) {
  return (
    <div className="px-4 py-3" style={{ borderLeft: `3px solid ${C.ink}`, background: "#fff" }}>
      <div className="text-xs" style={{ color: C.muted }}>{label}</div>
      <div className="text-2xl font-bold leading-tight" style={NUM}>{value}</div>
      <div className="text-xs mt-0.5">{delta ?? <span>&nbsp;</span>}</div>
    </div>
  );
}

// ============================================================
//                         App
// ============================================================
export default function App() {
  const [mode, setMode] = useState("live");
  const [loading, setLoading] = useState(true);
  const [cfg, setCfg] = useState(DEFAULT_CFG);
  const [register, setRegister] = useState({});
  const [manifest, setManifest] = useState({ gscW: new Set(), gscM: new Set(), rank: new Set(), idx: new Set() });
  const [log, setLog] = useState([]);
  const cache = useRef({});
  const [ver, setVer] = useState(0);
  const [tab, setTab] = useState("overview");
  const [ptype, setPtype] = useState("M");
  const [pid, setPid] = useState(lastCompleted("M").id);
  const [project, setProject] = useState("All");
  const [pageFilter, setPageFilter] = useState({ writer: "All", q: "", type: "All", alertsOnly: false });
  const [toast, setToast] = useState("");

  const flash = (m) => { setToast(m); setTimeout(() => setToast(""), 3500); };

  const refreshManifest = useCallback(async () => {
    const [g, r, i] = await Promise.all([S.list("cph:gsc:"), S.list("cph:rank:"), S.list("cph:idx:")]);
    const m = { gscW: new Set(), gscM: new Set(), rank: new Set(), idx: new Set() };
    g.forEach((k) => { const [, , t, id] = k.split(":"); if (t === "W") m.gscW.add(id); else if (t === "M") m.gscM.add(id); });
    r.forEach((k) => m.rank.add(k.split(":")[2]));
    i.forEach((k) => m.idx.add(k.split(":")[2]));
    setManifest(m);
    return m;
  }, []);

  const loadAll = useCallback(async () => {
    setLoading(true);
    cache.current = {};
    const [c, reg, lg] = await Promise.all([S.get(K.cfg), S.get(K.reg), S.get(K.log)]);
    setCfg(c ? { ...DEFAULT_CFG, ...c } : DEFAULT_CFG);
    setRegister(reg || {});
    setLog(lg || []);
    const m = await refreshManifest();
    // default period: latest month with GSC data, else last completed month
    const months = CAL.months.slice(0, CUR_MONTH_IDX + 1).filter((x) => m.gscM.has(x.id));
    if (months.length) { setPtype("M"); setPid(months[months.length - 1].id); }
    else {
      const weeks = CAL.weeks.slice(0, CUR_WEEK_IDX + 1).filter((x) => m.gscW.has(x.id));
      if (weeks.length) { setPtype("W"); setPid(weeks[weeks.length - 1].id); }
      else { setPtype("M"); setPid(lastCompleted("M").id); }
    }
    setVer((v) => v + 1);
    setLoading(false);
  }, [refreshManifest]);

  useEffect(() => { loadAll(); }, [loadAll]);

  const ensure = useCallback(async (keys) => {
    const missing = keys.filter((k) => k && !(k in cache.current));
    if (!missing.length) return;
    const vals = await Promise.all(missing.map((k) => S.get(k)));
    missing.forEach((k, i) => { cache.current[k] = vals[i]; });
    setVer((v) => v + 1);
  }, []);

  const P = getPeriod(ptype, pid) || lastCompleted(ptype);
  const PP = prevPeriod(P);
  const rankId = snapIn(P, manifest.rank), rankPrevId = snapIn(PP, manifest.rank);
  const idxIds = useMemo(() => CAL.weeks.filter((w) => w.end <= P.end && manifest.idx.has(w.id)).map((w) => w.id), [P.end, manifest]);

  useEffect(() => {
    if (loading) return;
    ensure([gscKey(P.type, P.id), PP && gscKey(PP.type, PP.id), rankId && rankKey(rankId), rankPrevId && rankKey(rankPrevId), ...idxIds.map(idxKey)]);
  }, [loading, P.type, P.id, PP, rankId, rankPrevId, idxIds, ensure, ver]);

  const ctx = useMemo(() => {
    const c = cache.current;
    const idxMap = {};
    for (const id of idxIds) { const m = c[idxKey(id)]; if (m) Object.assign(idxMap, m); }
    return {
      P, gsc: c[gscKey(P.type, P.id)] || null, gscPrev: PP ? c[gscKey(PP.type, PP.id)] || null : null,
      rank: rankId ? c[rankKey(rankId)] || null : null, rankPrev: rankPrevId ? c[rankKey(rankPrevId)] || null : null,
      rankId, rankPrevId, idxMap,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ver, P.id, P.type, rankId, rankPrevId, idxIds]);

  const projects = useMemo(() => ["All", ...Array.from(new Set(Object.values(cfg.domains)))], [cfg]);
  const stats = useMemo(() => Object.entries(register)
    .map(([key, reg]) => pageStat(key, reg, ctx, cfg))
    .filter((s) => project === "All" || s.project === project), [register, ctx, cfg, project]);

  // ---------- persistence helpers ----------
  const addLog = async (what) => {
    const cur = (await S.get(K.log)) || [];
    const next = [{ at: new Date().toLocaleString("en-US"), what }, ...cur].slice(0, 150);
    await S.set(K.log, next); setLog(next);
  };
  const mutateRegister = async (fn, what) => {
    const cur = (await S.get(K.reg)) || {};
    const next = fn({ ...cur });
    await S.set(K.reg, next); setRegister(next);
    if (what) await addLog(what);
    return next;
  };
  const saveCfg = async (next) => { await S.set(K.cfg, next); setCfg(next); };

  const switchMode = async (m) => {
    MODE = m;
    if (m === "demo") makeDemo();
    setMode(m);
    await loadAll();
  };

  const goPages = (f) => { setPageFilter({ writer: "All", q: "", type: "All", alertsOnly: false, ...f }); setTab("pages"); };

  const TABS = [["overview", "Overview"], ["pages", "Pages"], ["alerts", "Alerts"], ["import", "Import data"], ["setup", "Setup"]];
  const periodOptions = periodList(ptype).slice(0, (ptype === "W" ? CUR_WEEK_IDX : CUR_MONTH_IDX) + 1).reverse()
    .map((p) => {
      const has = ptype === "W" ? manifest.gscW.has(p.id) : manifest.gscM.has(p.id);
      return { v: p.id, l: `${p.label}${has ? "  ●" : ""}` };
    });

  return (
    <div style={{ background: C.paper, color: C.ink, fontFamily: FONT, minHeight: "100vh" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800&display=swap');
        button:focus-visible, select:focus-visible, input:focus-visible { outline: 2px solid ${C.cyan}; outline-offset: 1px; }
        @media (prefers-reduced-motion: reduce) { * { transition: none !important; animation: none !important; } }
        table.cph th { position: sticky; top: 0; background: ${C.soft}; z-index: 1; }`}</style>

      {mode === "demo" && (
        <div className="px-6 py-2 text-sm flex items-center justify-between" style={{ background: C.yel, color: C.ink }}>
          <span>Sample data — nothing you do here is saved.</span>
          <Btn small onClick={() => switchMode("live")}>Exit sample data</Btn>
        </div>
      )}

      <header className="px-6 pt-5" style={{ borderBottom: `1px solid ${C.rule}`, background: "#fff" }}>
        <div className="flex flex-wrap items-baseline justify-between gap-3">
          <div>
            <h1 className="text-2xl font-extrabold" style={{ letterSpacing: "-0.02em" }}>Content performance</h1>
            <div className="text-sm" style={{ color: C.muted }}>Print247 and CustomMylarBags, by writer. Weekly cycles close on Wednesday.</div>
          </div>
          {mode === "live" && <Btn small onClick={() => switchMode("demo")}>Preview with sample data</Btn>}
        </div>
        <nav className="flex gap-1 mt-4 overflow-x-auto" aria-label="Sections">
          {TABS.map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} className="px-3 py-2 text-sm font-semibold focus:outline-none whitespace-nowrap"
              style={{ borderBottom: tab === k ? `3px solid ${C.ink}` : "3px solid transparent", color: tab === k ? C.ink : C.muted }}>
              {l}{k === "alerts" && stats.length ? ` (${stats.reduce((s, x) => s + x.alerts.filter((a) => a.k !== "own").length, 0)})` : ""}
            </button>
          ))}
        </nav>
      </header>

      {(tab === "overview" || tab === "pages" || tab === "alerts") && (
        <div className="px-6 py-4" style={{ background: "#fff", borderBottom: `1px solid ${C.rule}` }}>
          <div className="flex flex-wrap items-center gap-3 mb-3">
            <div className="inline-flex rounded overflow-hidden" style={{ border: `1px solid ${C.rule}` }} role="group" aria-label="Period type">
              {[["W", "Weekly"], ["M", "Monthly"]].map(([t, l]) => (
                <button key={t} onClick={() => { setPtype(t); setPid(lastCompleted(t).id); }} className="px-3 py-1.5 text-sm font-semibold focus:outline-none"
                  style={{ background: ptype === t ? C.ink : "#fff", color: ptype === t ? "#fff" : C.ink }}>{l}</button>
              ))}
            </div>
            <Sel value={pid} onChange={setPid} options={periodOptions} />
            <Sel value={project} onChange={setProject} options={projects.map((p) => ({ v: p, l: p === "All" ? "All projects" : p }))} />
            <div className="text-xs" style={{ color: C.muted }}>
              {usDate(P.start)} – {usDate(P.end)} · compared with {PP ? PP.label : "–"}
              {ctx.rankId ? ` · ranks from ${ctx.rankId}` : " · no rank snapshot in this period"}
            </div>
          </div>
          <ColorBar type={ptype} manifest={manifest} selected={pid} onPick={setPid} />
        </div>
      )}

      <main className="px-6 py-5">
        {loading ? <div style={{ color: C.muted }}>Loading shared data…</div> : (
          <>
            {tab === "overview" && <Overview stats={stats} ctx={ctx} cfg={cfg} P={P} PP={PP} ptype={ptype} register={register}
              manifest={manifest} ensure={ensure} cache={cache} ver={ver} goPages={goPages} setTab={setTab} project={project} />}
            {tab === "pages" && <PagesView stats={stats} cfg={cfg} filter={pageFilter} setFilter={setPageFilter} P={P}
              mutateRegister={mutateRegister} flash={flash} />}
            {tab === "alerts" && <AlertsView stats={stats} cfg={cfg} goPages={goPages} />}
            {tab === "import" && <ImportView cfg={cfg} saveCfg={saveCfg} register={register} mutateRegister={mutateRegister}
              manifest={manifest} refreshManifest={refreshManifest} cache={cache} setVer={setVer} addLog={addLog} log={log} flash={flash} />}
            {tab === "setup" && <SetupView cfg={cfg} saveCfg={saveCfg} register={register} mutateRegister={mutateRegister}
              manifest={manifest} ensure={ensure} cache={cache} ver={ver} flash={flash} refreshManifest={refreshManifest} loadAll={loadAll} />}
          </>
        )}
      </main>

      {toast && (
        <div className="fixed bottom-4 right-4 px-4 py-2 rounded text-sm z-50" role="status" style={{ background: C.ink, color: "#fff" }}>{toast}</div>
      )}
    </div>
  );
}

// ============================================================
//                         Overview
// ============================================================
function Overview({ stats, ctx, cfg, P, PP, ptype, register, manifest, ensure, cache, ver, goPages, setTab, project }) {
  const empty = Object.keys(register).length === 0;
  const byWriter = useMemo(() => {
    const names = [...cfg.writers];
    if (stats.some((s) => !s.writer)) names.push("");
    stats.forEach((s) => { if (s.writer && !names.includes(s.writer)) names.push(s.writer); });
    return names.map((w) => ({ w, a: aggregate(stats.filter((s) => s.writer === w)) })).filter((x) => x.a.pages > 0 || x.w);
  }, [stats, cfg]);
  const tot = useMemo(() => aggregate(stats), [stats]);

  // trend: last 8 periods of same type
  const L = periodList(ptype);
  const iP = L.findIndex((x) => x.id === P.id);
  const trendPeriods = L.slice(Math.max(0, iP - 7), iP + 1);
  useEffect(() => { ensure(trendPeriods.map((p) => gscKey(p.type, p.id))); /* eslint-disable-next-line */ }, [P.id, ptype]);
  const trend = useMemo(() => trendPeriods.map((p) => {
    const g = cache.current[gscKey(p.type, p.id)];
    const row = { name: p.type === "W" ? p.id : p.label };
    if (!g) return row;
    for (const [key, reg] of Object.entries(register)) {
      const proj = cfg.domains[hostOf(key)] || hostOf(key);
      if (project !== "All" && proj !== project) continue;
      const w = reg.writer || "Unassigned"; const v = g[key];
      row[w] = (row[w] || 0) + (v ? v[0] : 0);
    }
    return row;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [ver, P.id, ptype, register, project]);
  const trendWriters = [...cfg.writers, ...(stats.some((s) => !s.writer) ? ["Unassigned"] : [])];

  const movers = useMemo(() => {
    const withD = stats.filter((s) => ctx.gscPrev && (s.clicks || s.pClicks));
    const up = [...withD].sort((a, b) => b.dClicks - a.dClicks).filter((s) => s.dClicks > 0).slice(0, 6);
    const down = [...withD].sort((a, b) => a.dClicks - b.dClicks).filter((s) => s.dClicks < 0).slice(0, 6);
    return { up, down };
  }, [stats, ctx.gscPrev]);

  if (empty) {
    return (
      <div className="max-w-2xl">
        <h2 className="text-xl font-bold mb-2">Set up in three steps</h2>
        <ol className="space-y-3 text-sm leading-6">
          <li><b>Load your pages.</b> Import one month of GSC data, then use Setup → Add pages from your data to pull in every /post/ and /knowledge/ URL at once. Or upload a sheet with URL and Writer columns.</li>
          <li><b>Assign writers.</b> On Pages, filter to “No writer”, tick the pages, and assign them in bulk. Writers can claim their own pages the same way.</li>
          <li><b>Import performance data.</b> GSC for clicks, Ahrefs or Semrush for keyword ranks, and optionally GSC indexing exports. Each file takes one drag and drop.</li>
        </ol>
        <div className="mt-5 flex gap-2"><Btn kind="primary" onClick={() => setTab("import")}><Upload size={15} /> Import data</Btn></div>
      </div>
    );
  }

  const noGsc = !ctx.gsc;
  return (
    <div className="space-y-6">
      {noGsc && (
        <div className="px-4 py-3 text-sm rounded" style={{ background: "#E6F4FA", color: C.ink }}>
          No GSC data for {P.label}. Export Search results for {usDate(P.start)}–{usDate(P.end)} and drop it on Import data.
        </div>
      )}
      <div className="grid gap-3" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))" }}>
        <Kpi label="Clicks" value={fmtInt(tot.clicks)} delta={<Delta v={tot.dClicksPct} pct />} />
        <Kpi label="Impressions" value={fmtInt(tot.impr)} delta={<Delta v={tot.pImpr ? (tot.impr - tot.pImpr) / tot.pImpr : null} pct />} />
        <Kpi label="CTR" value={fmtPct(tot.ctr, 2)} />
        <Kpi label="Avg position" value={fmtPos(tot.pos)} />
        <Kpi label="Keywords in top 10" value={ctx.rank ? fmtInt(tot.t10) : "–"} delta={ctx.rank && ctx.rankPrev ? <Delta v={tot.t10 - tot.pT10} /> : null} />
        <Kpi label="Pages seen in Google" value={`${fmtInt(tot.seen)} / ${fmtInt(tot.pages)}`} delta={<span style={{ color: C.muted }}>{fmtPct(tot.pages ? tot.seen / tot.pages : null)}</span>} />
        <Kpi label="New pieces" value={fmtInt(tot.newP)} delta={<span style={{ color: C.muted }}>published in period</span>} />
      </div>

      <section>
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-bold">By writer</h2>
          <Btn small onClick={() => downloadCSV(`writers-${P.id}.csv`,
            ["Writer", "Pages", "New", "Clicks", "Prev clicks", "Impressions", "CTR", "Avg position", "Seen in Google", "Top 3", "Top 10", "Top 20", "Alerts"],
            byWriter.map(({ w, a }) => [w || "No writer", a.pages, a.newP, a.clicks, a.pClicks, a.impr, a.ctr?.toFixed(4), a.pos?.toFixed(1), a.seen, a.t3, a.t10, a.t20, a.alerts]))}>
            <Download size={13} /> CSV</Btn>
        </div>
        <div className="overflow-x-auto rounded" style={{ border: `1px solid ${C.rule}`, background: "#fff" }}>
          <table className="cph w-full text-sm" style={NUM}>
            <thead><tr style={{ color: C.muted }} className="text-xs text-right">
              {["Writer", "Pages", "New", "Clicks", "vs prev", "Impressions", "CTR", "Avg pos", "Seen in Google", "Top 3", "Top 10", "Top 20", "Top 10 change", "Alerts"].map((h, i) => (
                <th key={h} className={`px-3 py-2 font-semibold ${i === 0 ? "text-left" : ""}`}>{h}</th>))}
            </tr></thead>
            <tbody>
              {byWriter.map(({ w, a }) => (
                <tr key={w || "_none"} className="text-right cursor-pointer" style={{ borderTop: `1px solid ${C.soft}` }}
                  onClick={() => goPages({ writer: w || "__none" })} title="Open this writer's pages">
                  <td className="px-3 py-2 text-left font-semibold">{w || <span style={{ color: C.down }}>No writer</span>}</td>
                  <td className="px-3 py-2">{fmtInt(a.pages)}</td>
                  <td className="px-3 py-2">{a.newP || "–"}</td>
                  <td className="px-3 py-2 font-semibold">{fmtInt(a.clicks)}</td>
                  <td className="px-3 py-2"><Delta v={a.dClicksPct} pct /></td>
                  <td className="px-3 py-2">{fmtInt(a.impr)}</td>
                  <td className="px-3 py-2">{fmtPct(a.ctr, 2)}</td>
                  <td className="px-3 py-2">{fmtPos(a.pos)}</td>
                  <td className="px-3 py-2">{a.pages ? fmtPct(a.seen / a.pages) : "–"}</td>
                  <td className="px-3 py-2">{ctx.rank ? a.t3 : "–"}</td>
                  <td className="px-3 py-2">{ctx.rank ? a.t10 : "–"}</td>
                  <td className="px-3 py-2">{ctx.rank ? a.t20 : "–"}</td>
                  <td className="px-3 py-2">{ctx.rank && ctx.rankPrev ? <Delta v={a.t10 - a.pT10} /> : "–"}</td>
                  <td className="px-3 py-2" style={{ color: a.alerts ? C.down : C.muted, fontWeight: a.alerts ? 700 : 400 }}>{a.alerts || "–"}</td>
                </tr>
              ))}
              <tr className="text-right font-bold" style={{ borderTop: `2px solid ${C.ink}` }}>
                <td className="px-3 py-2 text-left">Total</td><td className="px-3 py-2">{fmtInt(tot.pages)}</td><td className="px-3 py-2">{tot.newP || "–"}</td>
                <td className="px-3 py-2">{fmtInt(tot.clicks)}</td><td className="px-3 py-2"><Delta v={tot.dClicksPct} pct /></td>
                <td className="px-3 py-2">{fmtInt(tot.impr)}</td><td className="px-3 py-2">{fmtPct(tot.ctr, 2)}</td><td className="px-3 py-2">{fmtPos(tot.pos)}</td>
                <td className="px-3 py-2">{tot.pages ? fmtPct(tot.seen / tot.pages) : "–"}</td>
                <td className="px-3 py-2">{ctx.rank ? tot.t3 : "–"}</td><td className="px-3 py-2">{ctx.rank ? tot.t10 : "–"}</td><td className="px-3 py-2">{ctx.rank ? tot.t20 : "–"}</td>
                <td className="px-3 py-2">{ctx.rank && ctx.rankPrev ? <Delta v={tot.t10 - tot.pT10} /> : "–"}</td>
                <td className="px-3 py-2">{tot.alerts || "–"}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="text-xs mt-1" style={{ color: C.muted }}>Seen in Google = pages with at least one impression in the period. Click a row to open that writer's pages.</div>
      </section>

      <section className="grid gap-6" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(420px, 1fr))" }}>
        <div className="rounded p-4" style={{ background: "#fff", border: `1px solid ${C.rule}` }}>
          <h2 className="text-lg font-bold mb-1">Clicks by writer</h2>
          <div className="text-xs mb-2" style={{ color: C.muted }}>Last {trendPeriods.length} {ptype === "W" ? "cycles" : "months"}. Gaps mean that period hasn't been imported.</div>
          <div style={{ height: 260 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trend} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid stroke={C.soft} vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: C.muted }} />
                <YAxis tick={{ fontSize: 11, fill: C.muted }} />
                <Tooltip contentStyle={{ fontFamily: FONT, fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                {trendWriters.map((w, i) => <Line key={w} type="monotone" dataKey={w} stroke={SERIES[i % SERIES.length]} strokeWidth={2} dot={{ r: 2 }} connectNulls={false} />)}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded p-4" style={{ background: "#fff", border: `1px solid ${C.rule}` }}>
          <h2 className="text-lg font-bold mb-2">Biggest movers vs {PP ? PP.label : "previous"}</h2>
          {!ctx.gscPrev ? <div className="text-sm" style={{ color: C.muted }}>Import GSC data for {PP ? PP.label : "the previous period"} to compare.</div> : (
            <div className="grid grid-cols-2 gap-4 text-sm">
              {[["Gaining", movers.up], ["Losing", movers.down]].map(([h, list]) => (
                <div key={h}>
                  <div className="text-xs font-semibold mb-1" style={{ color: C.muted }}>{h}</div>
                  {list.length === 0 && <div style={{ color: C.muted }}>None</div>}
                  {list.map((s) => (
                    <div key={s.key} className="py-1.5" style={{ borderTop: `1px solid ${C.soft}` }}>
                      <div className="truncate font-medium" title={s.key}>{s.reg.title || pathOf(s.key)}</div>
                      <div className="flex justify-between text-xs" style={{ color: C.muted }}>
                        <span>{s.writer || "No writer"}</span><span style={NUM}>{fmtInt(s.pClicks)} → {fmtInt(s.clicks)} <Delta v={s.dClicks} /></span>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

// ============================================================
//                         Pages
// ============================================================
function PagesView({ stats, cfg, filter, setFilter, P, mutateRegister, flash }) {
  const [sort, setSort] = useState({ k: "clicks", d: -1 });
  const [page, setPage] = useState(0);
  const [sel, setSel] = useState(new Set());
  const [edit, setEdit] = useState(null);
  const [adding, setAdding] = useState(false);
  const [bulkWriter, setBulkWriter] = useState("");
  const [bulkType, setBulkType] = useState("");
  const PER = 50;

  const rows = useMemo(() => {
    const q = filter.q.trim().toLowerCase();
    let r = stats.filter((s) =>
      (filter.writer === "All" || (filter.writer === "__none" ? !s.writer : s.writer === filter.writer)) &&
      (filter.type === "All" || (filter.type === "__none" ? !s.reg.type : s.reg.type === filter.type)) &&
      (!filter.alertsOnly || s.alerts.some((a) => a.k !== "own")) &&
      (!q || s.key.includes(q) || (s.reg.title || "").toLowerCase().includes(q) || (s.pk || "").toLowerCase().includes(q)));
    const val = (s) => {
      switch (sort.k) {
        case "page": return s.reg.title || pathOf(s.key);
        case "writer": return s.writer || "~";
        case "pub": return s.reg.pub || "";
        case "pos": return s.pos ?? 999;
        case "pk": return s.pkPos ?? 999;
        default: return s[sort.k] ?? 0;
      }
    };
    r = [...r].sort((a, b) => { const x = val(a), y = val(b); return (x < y ? -1 : x > y ? 1 : 0) * sort.d; });
    return r;
  }, [stats, filter, sort]);
  useEffect(() => { setPage(0); setSel(new Set()); }, [filter]);
  const pageRows = rows.slice(page * PER, page * PER + PER);
  const pages = Math.max(1, Math.ceil(rows.length / PER));

  const th = (k, label, right = true) => (
    <th className={`px-2 py-2 font-semibold cursor-pointer select-none ${right ? "text-right" : "text-left"}`}
      onClick={() => setSort((s) => ({ k, d: s.k === k ? -s.d : k === "page" || k === "writer" || k === "pos" || k === "pk" ? 1 : -1 }))}>
      {label}{sort.k === k ? (sort.d > 0 ? " ↑" : " ↓") : ""}
    </th>
  );
  const toggle = (key) => setSel((s) => { const n = new Set(s); n.has(key) ? n.delete(key) : n.add(key); return n; });
  const allOnPage = pageRows.length > 0 && pageRows.every((r) => sel.has(r.key));

  const applyBulk = async () => {
    if (!sel.size) return;
    const keys = [...sel];
    await mutateRegister((reg) => {
      keys.forEach((k) => { if (reg[k]) reg[k] = { ...reg[k], ...(bulkWriter ? { writer: bulkWriter === "__clear" ? "" : bulkWriter } : {}), ...(bulkType ? { type: bulkType } : {}) }; });
      return reg;
    }, `Updated ${keys.length} pages${bulkWriter ? ` → ${bulkWriter === "__clear" ? "no writer" : bulkWriter}` : ""}${bulkType ? ` · ${bulkType}` : ""}`);
    flash(`Updated ${keys.length} pages`); setSel(new Set()); setBulkWriter(""); setBulkType("");
  };
  const removeSel = async () => {
    if (!sel.size || !confirm(`Remove ${sel.size} pages from tracking? Their imported data stays and returns if you add them again.`)) return;
    const keys = [...sel];
    await mutateRegister((reg) => { keys.forEach((k) => delete reg[k]); return reg; }, `Removed ${keys.length} pages from tracking`);
    flash(`Removed ${keys.length} pages`); setSel(new Set());
  };

  const writerOpts = [{ v: "All", l: "All writers" }, { v: "__none", l: "No writer" }, ...cfg.writers.map((w) => ({ v: w, l: w }))];
  const typeOpts = [{ v: "All", l: "All types" }, { v: "__none", l: "No type" }, ...cfg.types.map((t) => ({ v: t, l: t }))];

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2 mb-3">
        <div className="relative">
          <Search size={14} className="absolute left-2 top-2.5" style={{ color: C.muted }} />
          <input value={filter.q} onChange={(e) => setFilter({ ...filter, q: e.target.value })} placeholder="Search URL, title, keyword"
            className="text-sm rounded pl-7 pr-2 py-1.5 focus:outline-none" style={{ ...inputStyle, width: 240 }} />
        </div>
        <Sel value={filter.writer} onChange={(v) => setFilter({ ...filter, writer: v })} options={writerOpts} />
        <Sel value={filter.type} onChange={(v) => setFilter({ ...filter, type: v })} options={typeOpts} />
        <label className="text-sm flex items-center gap-1.5"><input type="checkbox" checked={filter.alertsOnly} onChange={(e) => setFilter({ ...filter, alertsOnly: e.target.checked })} /> Only pages with alerts</label>
        <div className="flex-1" />
        <Btn small onClick={() => downloadCSV(`pages-${P.id}.csv`,
          ["URL", "Title", "Writer", "Project", "Type", "Published", "Clicks", "Prev clicks", "Impressions", "CTR", "Avg position", "Keywords", "Top 10", "Primary keyword", "Primary kw position", "Prev position", "Index", "Alerts"],
          rows.map((s) => ["https://" + s.key, s.reg.title, s.writer, s.project, s.reg.type, s.reg.pub, s.clicks, s.pClicks, s.impr, s.ctr?.toFixed(4), s.pos?.toFixed(1), s.n, s.t10, s.pk, s.pkPos, s.pkPrev, s.idx, s.alerts.map((a) => a.t).join("; ")]))}>
          <Download size={13} /> CSV</Btn>
        <Btn small kind="primary" onClick={() => setAdding(true)}><Plus size={13} /> Add page</Btn>
      </div>

      {sel.size > 0 && (
        <div className="flex flex-wrap items-center gap-2 mb-3 px-3 py-2 rounded" style={{ background: C.ink, color: "#fff" }}>
          <span className="text-sm font-semibold">{sel.size} selected</span>
          <Sel value={bulkWriter} onChange={setBulkWriter} options={[{ v: "", l: "Set writer…" }, ...cfg.writers.map((w) => ({ v: w, l: w })), { v: "__clear", l: "Clear writer" }]} />
          <Sel value={bulkType} onChange={setBulkType} options={[{ v: "", l: "Set type…" }, ...cfg.types.map((t) => ({ v: t, l: t }))]} />
          <Btn small onClick={applyBulk} disabled={!bulkWriter && !bulkType}><Check size={13} /> Apply</Btn>
          <Btn small kind="danger" onClick={removeSel}><Trash2 size={13} /> Stop tracking</Btn>
          <button className="text-sm underline ml-auto" onClick={() => setSel(new Set())}>Clear selection</button>
        </div>
      )}

      <div className="overflow-x-auto rounded" style={{ border: `1px solid ${C.rule}`, background: "#fff" }}>
        <table className="cph w-full text-sm" style={NUM}>
          <thead><tr className="text-xs" style={{ color: C.muted }}>
            <th className="px-2 py-2 w-8"><input type="checkbox" aria-label="Select page" checked={allOnPage}
              onChange={() => setSel((s) => { const n = new Set(s); pageRows.forEach((r) => (allOnPage ? n.delete(r.key) : n.add(r.key))); return n; })} /></th>
            {th("page", "Page", false)}{th("writer", "Writer", false)}{th("pub", "Published", false)}
            {th("clicks", "Clicks")}{th("dClicks", "vs prev")}{th("impr", "Impr.")}{th("pos", "Avg pos")}
            {th("t10", "Top 10 / KWs")}{th("pk", "Primary keyword", false)}<th className="px-2 py-2 text-left font-semibold">Index</th>
            <th className="px-2 py-2 text-left font-semibold">Alerts</th>
          </tr></thead>
          <tbody>
            {pageRows.length === 0 && <tr><td colSpan={12} className="px-3 py-8 text-center" style={{ color: C.muted }}>No pages match these filters.</td></tr>}
            {pageRows.map((s) => (
              <tr key={s.key} style={{ borderTop: `1px solid ${C.soft}`, background: sel.has(s.key) ? "#EAF6FB" : undefined }}>
                <td className="px-2 py-1.5"><input type="checkbox" aria-label="Select page" checked={sel.has(s.key)} onChange={() => toggle(s.key)} /></td>
                <td className="px-2 py-1.5" style={{ maxWidth: 320 }}>
                  <button className="text-left font-medium hover:underline block truncate w-full focus:outline-none" onClick={() => setEdit(s)} title="Edit page details">
                    {s.reg.title || pathOf(s.key)}
                  </button>
                  <a href={s.reg.url || "https://" + s.key} target="_blank" rel="noreferrer" className="text-xs inline-flex items-center gap-1 truncate" style={{ color: C.muted, maxWidth: 300 }}>
                    {s.key.length > 48 ? s.key.slice(0, 48) + "…" : s.key} <ExternalLink size={10} />
                  </a>
                </td>
                <td className="px-2 py-1.5">
                  <select value={s.writer} onChange={async (e) => { const v = e.target.value; await mutateRegister((reg) => { reg[s.key] = { ...reg[s.key], writer: v }; return reg; }); }}
                    className="text-sm rounded px-1 py-0.5 focus:outline-none" style={{ border: `1px solid ${s.writer ? C.soft : C.down}`, background: "#fff", color: s.writer ? C.ink : C.down }}>
                    <option value="">No writer</option>
                    {cfg.writers.map((w) => <option key={w} value={w}>{w}</option>)}
                  </select>
                  <div className="text-xs" style={{ color: C.muted }}>{s.reg.type || "No type"}</div>
                </td>
                <td className="px-2 py-1.5 whitespace-nowrap">{s.reg.pub ? usDate(s.reg.pub) : <span style={{ color: C.muted }}>–</span>}{s.isNew && <span className="ml-1 text-xs px-1 rounded" style={{ background: C.yel }}>new</span>}</td>
                <td className="px-2 py-1.5 text-right font-semibold">{fmtInt(s.clicks)}</td>
                <td className="px-2 py-1.5 text-right"><Delta v={s.dClicks} /></td>
                <td className="px-2 py-1.5 text-right">{fmtInt(s.impr)}</td>
                <td className="px-2 py-1.5 text-right">{fmtPos(s.pos)}</td>
                <td className="px-2 py-1.5 text-right">{s.hasRank ? `${s.t10} / ${s.n}` : "–"}</td>
                <td className="px-2 py-1.5" style={{ maxWidth: 220 }}>
                  {s.pk ? (
                    <div>
                      <div className="truncate" title={s.pk}>{s.pk}{s.pkAuto && <span className="text-xs ml-1" style={{ color: C.muted }}>(auto)</span>}</div>
                      <div className="text-xs" style={{ color: C.muted }}>
                        #{s.pkPos ?? "–"} {s.pkPos && s.pkPrev ? <Delta v={s.pkPrev - s.pkPos} /> : null}{s.pkVol ? ` · ${fmtInt(s.pkVol)}/mo` : ""}
                      </div>
                    </div>
                  ) : <span style={{ color: C.muted }}>–</span>}
                </td>
                <td className="px-2 py-1.5"><IdxBadge s={s.idx} inferred={s.idxInferred} /></td>
                <td className="px-2 py-1.5 text-xs" style={{ color: C.down, maxWidth: 200 }}>{s.alerts.filter((a) => a.k !== "own").map((a) => a.t).join(" · ")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex items-center justify-between mt-2 text-sm" style={{ color: C.muted }}>
        <span>{rows.length.toLocaleString()} pages · Indexed* = inferred from Google impressions</span>
        <div className="flex items-center gap-2">
          <Btn small disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</Btn>
          <span style={NUM}>{page + 1} / {pages}</span>
          <Btn small disabled={page >= pages - 1} onClick={() => setPage(page + 1)}>Next</Btn>
        </div>
      </div>

      {(edit || adding) && <PageEditor s={edit} cfg={cfg} onClose={() => { setEdit(null); setAdding(false); }}
        onSave={async (key, data, isNew) => {
          await mutateRegister((reg) => {
            if (isNew && reg[key]) throw new Error("exists");
            reg[key] = { ...(reg[key] || { added: TODAY }), ...data }; return reg;
          }, isNew ? `Added ${key}` : null).then(() => { flash(isNew ? "Page added" : "Saved"); setEdit(null); setAdding(false); })
            .catch(() => flash("That URL is already being tracked"));
        }} />}
    </div>
  );
}

function PageEditor({ s, cfg, onClose, onSave }) {
  const isNew = !s;
  const [d, setD] = useState(s ? { url: s.reg.url || "https://" + s.key, writer: s.reg.writer || "", type: s.reg.type || "", title: s.reg.title || "", pub: s.reg.pub || "", pk: s.reg.pk || "" }
    : { url: "", writer: "", type: "", title: "", pub: TODAY, pk: "" });
  const key = normKey(d.url);
  return (
    <Modal title={isNew ? "Add a published page" : "Edit page"} onClose={onClose}>
      <Field label="Live URL">
        <Input value={d.url} disabled={!isNew} onChange={(e) => setD({ ...d, url: e.target.value })} placeholder="https://print247.us/post/…" />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Writer"><Sel value={d.writer} onChange={(v) => setD({ ...d, writer: v })} options={[{ v: "", l: "No writer" }, ...cfg.writers]} style={{ width: "100%" }} /></Field>
        <Field label="Content type"><Sel value={d.type} onChange={(v) => setD({ ...d, type: v })} options={[{ v: "", l: "Not set" }, ...cfg.types]} style={{ width: "100%" }} /></Field>
      </div>
      <Field label="Title"><Input value={d.title} onChange={(e) => setD({ ...d, title: e.target.value })} /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Publish date"><Input type="date" value={d.pub} onChange={(e) => setD({ ...d, pub: e.target.value })} /></Field>
        <Field label="Primary keyword" hint="Leave blank to use the page's top keyword from Ahrefs/Semrush"><Input value={d.pk} onChange={(e) => setD({ ...d, pk: e.target.value })} /></Field>
      </div>
      <div className="flex justify-end gap-2 mt-2">
        <Btn onClick={onClose}>Cancel</Btn>
        <Btn kind="primary" disabled={!key || !key.includes(".")} onClick={() => onSave(key, { url: d.url.trim(), writer: d.writer, type: d.type, title: d.title.trim(), pub: d.pub, pk: d.pk.trim() }, isNew)}>
          {isNew ? "Add page" : "Save"}</Btn>
      </div>
    </Modal>
  );
}

// ============================================================
//                         Alerts
// ============================================================
function AlertsView({ stats, cfg, goPages }) {
  const [w, setW] = useState("All");
  const groups = [
    ["idx", "Not indexed", "GSC indexing export says Google hasn't indexed these. Request indexing, add internal links, check for thin or duplicate content."],
    ["vis", "No Google impressions", "Live 3+ weeks with zero impressions in this period. Usually not indexed, cannibalized, or targeting a keyword nobody searches."],
    ["drop", "Clicks dropped 30%+", "Compared with the previous period (pages with 10+ clicks before). Check ranking loss, AI Overviews, or a competitor page."],
    ["kw", "Primary keyword slipped", "Left the top 10 or fell 5+ positions since the previous rank snapshot."],
    ["own", "No writer assigned", "These pages don't count toward anyone. Assign them on Pages."],
  ];
  const f = stats.filter((s) => w === "All" || (w === "__none" ? !s.writer : s.writer === w));
  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <Sel value={w} onChange={setW} options={[{ v: "All", l: "All writers" }, { v: "__none", l: "No writer" }, ...cfg.writers]} />
      </div>
      <div className="grid gap-4" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(360px, 1fr))" }}>
        {groups.map(([k, h, help]) => {
          const list = f.filter((s) => s.alerts.some((a) => a.k === k));
          return (
            <section key={k} className="rounded" style={{ background: "#fff", border: `1px solid ${C.rule}` }}>
              <div className="px-4 py-3" style={{ borderBottom: `1px solid ${C.soft}` }}>
                <div className="flex items-center justify-between">
                  <h2 className="font-bold flex items-center gap-2">{list.length > 0 && <AlertTriangle size={15} style={{ color: C.down }} />}{h}</h2>
                  <span className="text-lg font-bold" style={{ ...NUM, color: list.length ? C.down : C.muted }}>{list.length}</span>
                </div>
                <div className="text-xs mt-1" style={{ color: C.muted }}>{help}</div>
              </div>
              <div style={{ maxHeight: 320, overflowY: "auto" }}>
                {list.length === 0 && <div className="px-4 py-3 text-sm" style={{ color: C.muted }}>Nothing here.</div>}
                {list.slice(0, 100).map((s) => (
                  <div key={s.key} className="px-4 py-2 text-sm" style={{ borderTop: `1px solid ${C.soft}` }}>
                    <div className="flex justify-between gap-2">
                      <a href={s.reg.url || "https://" + s.key} target="_blank" rel="noreferrer" className="truncate font-medium hover:underline" title={s.key}>{s.reg.title || pathOf(s.key)}</a>
                      <span className="text-xs whitespace-nowrap" style={{ color: C.muted }}>{s.writer || "No writer"}</span>
                    </div>
                    <div className="text-xs" style={{ color: C.down }}>{s.alerts.filter((a) => a.k === k).map((a) => a.t).join(" · ")}</div>
                  </div>
                ))}
              </div>
              {k === "own" && list.length > 0 && <div className="px-4 py-2"><Btn small onClick={() => goPages({ writer: "__none" })}>Assign writers</Btn></div>}
            </section>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================
//                         Import
// ============================================================
const TYPE_LABEL = {
  gsc: "Google Search Console — performance by page", ranks: "Keyword rankings", index: "GSC indexing list",
  urls: "URL list", mapping: "Pages with writer names", gscQueries: "GSC queries (site-wide)",
};

function ImportView({ cfg, saveCfg, register, mutateRegister, manifest, refreshManifest, cache, setVer, addLog, log, flash }) {
  const [items, setItems] = useState([]);
  const [drag, setDrag] = useState(false);
  const inputRef = useRef(null);

  const handleFiles = async (files) => {
    const next = [];
    for (const file of Array.from(files)) {
      try {
        const det = await readAny(file);
        if (!det) { next.push({ id: Math.random(), file: file.name, error: "Couldn't recognize this file. Use a GSC Pages export, an Ahrefs/Semrush organic keywords export, a GSC indexing export, or a sheet with URL (and Writer) columns." }); continue; }
        if (det.type === "gscQueries") { next.push({ id: Math.random(), file: file.name, error: "This is the Queries sheet. Export from Search results as Excel — the Pages sheet inside it is read automatically." }); continue; }
        const parsed = parseDetected(det);
        const cur = CAL.weeks[CUR_WEEK_IDX];
        next.push({ id: Math.random(), file: file.name, det, parsed,
          opt: det.type === "gsc" ? { ptype: "M", pid: lastCompleted("M").id, replace: false }
            : det.type === "ranks" ? { pid: cur.id, replace: false }
            : det.type === "index" ? { pid: cur.id, status: "Indexed" }
            : det.type === "urls" ? { writer: "", type: "" } : { addNew: true } });
      } catch (e) { next.push({ id: Math.random(), file: file.name, error: `Couldn't read this file: ${e.message}` }); }
    }
    setItems((it) => [...next, ...it]);
  };

  const setOpt = (id, patch) => setItems((it) => it.map((x) => (x.id === id ? { ...x, opt: { ...x.opt, ...patch } } : x)));
  const done = (id, msg) => setItems((it) => it.map((x) => (x.id === id ? { ...x, done: msg } : x)));

  const save = async (it) => {
    try {
      const t = it.det.type;
      if (t === "gsc") {
        const k = gscKey(it.opt.ptype, it.opt.pid);
        const prev = it.opt.replace ? null : await S.get(k);
        const data = prev ? { ...prev, ...it.parsed.data } : it.parsed.data;
        await S.set(k, data); cache.current[k] = data;
        const label = getPeriod(it.opt.ptype, it.opt.pid).label;
        const how = prev ? ` (combined with earlier import → ${Object.keys(data).length} pages)` : it.opt.replace ? " (replaced)" : "";
        await addLog(`GSC ${it.opt.ptype === "W" ? "cycle" : "month"} ${label}: ${it.parsed.summary}${how}`);
        done(it.id, `Saved as ${label}${how}`);
      } else if (t === "ranks") {
        const k = rankKey(it.opt.pid);
        const prev = it.opt.replace ? null : await S.get(k);
        const fresh = trimRanks(it.parsed.data, register);
        const data = prev ? { src: prev.src === it.det.source ? prev.src : `${prev.src} + ${it.det.source}`, at: TODAY, pages: { ...prev.pages, ...fresh } }
          : { src: it.det.source, at: TODAY, pages: fresh };
        await S.set(k, data); cache.current[k] = data;
        await addLog(`${it.det.source} ranks for ${it.opt.pid}: ${it.parsed.summary}`);
        done(it.id, `Saved as rank snapshot ${it.opt.pid}`);
      } else if (t === "index") {
        const k = idxKey(it.opt.pid);
        const cur = (await S.get(k)) || {};
        it.parsed.data.forEach((u) => { cur[normKey(u)] = it.opt.status; });
        await S.set(k, cur); cache.current[k] = cur;
        await addLog(`Index check ${it.opt.pid}: ${it.parsed.data.length} URLs marked ${it.opt.status}`);
        done(it.id, `${it.parsed.data.length} URLs marked ${it.opt.status} for ${it.opt.pid}`);
      } else if (t === "urls") {
        let added = 0;
        await mutateRegister((reg) => {
          it.parsed.data.forEach((u) => { const k = normKey(u); if (k && !reg[k]) { reg[k] = { url: u, writer: it.opt.writer, type: it.opt.type, title: "", pub: "", pk: "", added: TODAY }; added++; } });
          return reg;
        });
        await addLog(`Added ${added} pages from ${it.file}`);
        done(it.id, `Added ${added} new pages (${it.parsed.data.length - added} were already tracked)`);
      } else if (t === "mapping") {
        const known = new Map(cfg.writers.map((w) => [w.toLowerCase(), w]));
        const newWriters = [];
        it.parsed.data.forEach((r) => { if (r.writer && !known.has(r.writer.toLowerCase())) { known.set(r.writer.toLowerCase(), r.writer); newWriters.push(r.writer); } });
        if (newWriters.length) await saveCfg({ ...cfg, writers: [...cfg.writers, ...newWriters] });
        const knownTypes = new Map(cfg.types.map((x) => [x.toLowerCase(), x]));
        let updated = 0, added = 0;
        await mutateRegister((reg) => {
          it.parsed.data.forEach((r) => {
            const k = normKey(r.url); if (!k) return;
            const patch = {};
            if (r.writer) patch.writer = known.get(r.writer.toLowerCase());
            if (r.type) patch.type = knownTypes.get(r.type.toLowerCase()) || r.type;
            if (r.title) patch.title = r.title; if (r.pub) patch.pub = r.pub; if (r.pk) patch.pk = r.pk;
            if (reg[k]) { reg[k] = { ...reg[k], ...patch }; updated++; }
            else if (it.opt.addNew) { reg[k] = { url: r.url, writer: "", type: "", title: "", pub: "", pk: "", added: TODAY, ...patch }; added++; }
          });
          return reg;
        });
        await addLog(`Writer mapping ${it.file}: ${updated} updated, ${added} added${newWriters.length ? `, new writers: ${newWriters.join(", ")}` : ""}`);
        done(it.id, `${updated} pages updated, ${added} added${newWriters.length ? ` · added writers ${newWriters.join(", ")}` : ""}`);
      }
      await refreshManifest(); setVer((v) => v + 1);
      flash("Saved");
    } catch (e) { flash(e.message || "Save failed"); }
  };

  const recentW = CAL.weeks.slice(Math.max(0, CUR_WEEK_IDX - 40), CUR_WEEK_IDX + 1).reverse();
  const recentM = CAL.months.slice(Math.max(0, CUR_MONTH_IDX - 17), CUR_MONTH_IDX + 1).reverse();

  return (
    <div className="grid gap-6" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(340px, 1fr))" }}>
      <div>
        <div onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); handleFiles(e.dataTransfer.files); }}
          className="rounded-lg p-8 text-center cursor-pointer" onClick={() => inputRef.current && inputRef.current.click()}
          style={{ border: `2px dashed ${drag ? C.cyan : C.rule}`, background: drag ? "#E6F4FA" : "#fff" }}>
          <Upload size={28} className="mx-auto mb-2" style={{ color: C.cyan }} />
          <div className="font-semibold">Drop export files here, or click to choose</div>
          <div className="text-sm mt-1" style={{ color: C.muted }}>CSV or Excel from GSC, Ahrefs, Semrush, or your own sheets. The file type is recognized automatically.</div>
          <input ref={inputRef} type="file" multiple accept=".csv,.tsv,.txt,.xlsx,.xls" className="hidden" onChange={(e) => { handleFiles(e.target.files); e.target.value = ""; }} />
        </div>

        <div className="space-y-3 mt-4">
          {items.map((it) => (
            <div key={it.id} className="rounded p-4" style={{ background: "#fff", border: `1px solid ${it.error ? C.down : it.done ? C.up : C.rule}` }}>
              <div className="flex justify-between gap-2">
                <div className="min-w-0">
                  <div className="font-semibold truncate">{it.file}</div>
                  {it.det && <div className="text-sm" style={{ color: C.muted }}>{TYPE_LABEL[it.det.type]}{it.det.sheet ? ` · sheet “${it.det.sheet}”` : ""} · {it.parsed.summary}</div>}
                </div>
                <button onClick={() => setItems((x) => x.filter((y) => y.id !== it.id))} aria-label="Dismiss" className="p-1 focus:outline-none"><X size={16} /></button>
              </div>
              {it.error && <div className="text-sm mt-2" style={{ color: C.down }}>{it.error}</div>}
              {it.done && <div className="text-sm mt-2 font-semibold" style={{ color: C.up }}><Check size={14} className="inline" /> {it.done}</div>}
              {!it.error && !it.done && (
                <div className="flex flex-wrap items-end gap-2 mt-3">
                  {it.det.type === "gsc" && (<>
                    <Field label="This export covers">
                      <div className="flex gap-2">
                        <Sel value={it.opt.ptype} onChange={(v) => setOpt(it.id, { ptype: v, pid: lastCompleted(v).id })} options={[{ v: "M", l: "A month" }, { v: "W", l: "A weekly cycle" }]} />
                        <Sel value={it.opt.pid} onChange={(v) => setOpt(it.id, { pid: v })} options={(it.opt.ptype === "W" ? recentW : recentM).map((p) => ({ v: p.id, l: p.label + ((it.opt.ptype === "W" ? manifest.gscW : manifest.gscM).has(p.id) ? "  (imported)" : "") }))} />
                      </div>
                    </Field>
                    <div className="text-xs mb-3" style={{ color: C.muted }}>GSC date range must be {usDate(getPeriod(it.opt.ptype, it.opt.pid).start)} – {usDate(getPeriod(it.opt.ptype, it.opt.pid).end)}</div>
                    <label className="text-xs flex items-center gap-1.5 mb-3 w-full"><input type="checkbox" checked={it.opt.replace} onChange={(e) => setOpt(it.id, { replace: e.target.checked })} /> Replace this period entirely (default adds to it, so split exports for /post/ and /knowledge/ combine)</label>
                  </>)}
                  {it.det.type === "ranks" && (
                    <Field label="Snapshot belongs to cycle" hint="Use the cycle when the export was taken (or the Ahrefs/Semrush date you picked for backfill).">
                      <Sel value={it.opt.pid} onChange={(v) => setOpt(it.id, { pid: v })} options={recentW.map((p) => ({ v: p.id, l: p.label + (manifest.rank.has(p.id) ? "  (imported)" : "") }))} />
                    </Field>
                  )}
                  {it.det.type === "ranks" && (
                    <label className="text-xs flex items-center gap-1.5 mb-3 w-full"><input type="checkbox" checked={it.opt.replace} onChange={(e) => setOpt(it.id, { replace: e.target.checked })} /> Replace this snapshot entirely (default adds to it, so Print247 and CustomMylarBags exports combine)</label>
                  )}
                  {it.det.type === "index" && (<>
                    <Field label="Cycle"><Sel value={it.opt.pid} onChange={(v) => setOpt(it.id, { pid: v })} options={recentW.map((p) => ({ v: p.id, l: p.label }))} /></Field>
                    <Field label="These URLs are"><Sel value={it.opt.status} onChange={(v) => setOpt(it.id, { status: v })} options={INDEX_STATUSES} /></Field>
                  </>)}
                  {it.det.type === "urls" && (<>
                    <Field label="Writer for all (optional)"><Sel value={it.opt.writer} onChange={(v) => setOpt(it.id, { writer: v })} options={[{ v: "", l: "Assign later" }, ...cfg.writers]} /></Field>
                    <Field label="Type for all (optional)"><Sel value={it.opt.type} onChange={(v) => setOpt(it.id, { type: v })} options={[{ v: "", l: "Set later" }, ...cfg.types]} /></Field>
                  </>)}
                  {it.det.type === "mapping" && (
                    <label className="text-sm flex items-center gap-1.5 mb-3"><input type="checkbox" checked={it.opt.addNew} onChange={(e) => setOpt(it.id, { addNew: e.target.checked })} /> Also start tracking URLs that aren't tracked yet</label>
                  )}
                  <div className="mb-3"><Btn kind="primary" onClick={() => save(it)}>{it.det.type === "urls" ? "Add pages" : it.det.type === "mapping" ? "Apply writers" : "Save import"}</Btn></div>
                </div>
              )}
            </div>
          ))}
        </div>

        <h2 className="text-lg font-bold mt-8 mb-2">Import history</h2>
        <div className="rounded text-sm" style={{ background: "#fff", border: `1px solid ${C.rule}`, maxHeight: 260, overflowY: "auto" }}>
          {log.length === 0 && <div className="px-4 py-3" style={{ color: C.muted }}>Nothing imported yet.</div>}
          {log.map((l, i) => (
            <div key={i} className="px-4 py-2 flex gap-3" style={{ borderTop: i ? `1px solid ${C.soft}` : "none" }}>
              <span className="whitespace-nowrap text-xs" style={{ color: C.muted, ...NUM }}>{l.at}</span><span>{l.what}</span>
            </div>
          ))}
        </div>
      </div>

      <aside className="text-sm leading-6">
        <h2 className="text-lg font-bold mb-2">Where each file comes from</h2>
        <div className="space-y-4">
          <div className="rounded p-4" style={{ background: "#fff", borderLeft: `4px solid ${C.cyan}` }}>
            <div className="font-bold">GSC clicks and impressions</div>
            <div>Search Console → Performance → Search results → Date → Custom → pick the cycle or month → Export → Download Excel. Drop the whole file; the Pages sheet is read.</div>
            <div>GSC exports stop at 1,000 rows. Add a Page filter (URLs containing /post/, then /knowledge/, and so on), export each, and import them all for the same period; they combine.</div>
            <div style={{ color: C.muted }}>Backfill: GSC keeps 16 months. Export each past month once and your history is complete on day one.</div>
          </div>
          <div className="rounded p-4" style={{ background: "#fff", borderLeft: `4px solid ${C.mag}` }}>
            <div className="font-bold">Keyword ranks — Ahrefs or Semrush</div>
            <div>Ahrefs: Site Explorer → print247.us → Organic keywords → United States → Export → all rows. Semrush: Organic Research → Positions → US → Export.</div>
            <div style={{ color: C.muted }}>Backfill: pick a past date in Ahrefs (date picker) or a past database in Semrush and assign it to that cycle. Use one tool consistently.</div>
          </div>
          <div className="rounded p-4" style={{ background: "#fff", borderLeft: `4px solid ${C.yel}` }}>
            <div className="font-bold">Index status (optional)</div>
            <div>Search Console → Indexing → Pages → View data about indexed pages → Export. For each “Why pages aren't indexed” reason, open it → Export, and choose the matching status.</div>
            <div style={{ color: C.muted }}>Without this, any page with Google impressions shows as Indexed*.</div>
          </div>
          <div className="rounded p-4" style={{ background: "#fff", borderLeft: `4px solid ${C.ink}` }}>
            <div className="font-bold">Your own page list</div>
            <div>A sheet with columns URL and Writer (optional: Type, Title, Publish date, Primary keyword). Use your old allocation sheets to credit two years of content in one upload.</div>
          </div>
        </div>
      </aside>
    </div>
  );
}

// ============================================================
//                         Setup
// ============================================================
function SetupView({ cfg, saveCfg, register, mutateRegister, manifest, ensure, cache, ver, flash, refreshManifest, loadAll }) {
  const [newWriter, setNewWriter] = useState("");
  const [newType, setNewType] = useState("");
  const [dom, setDom] = useState({ host: "", project: "" });
  const [src, setSrc] = useState("");
  const [pathQ, setPathQ] = useState("/post/");
  const [picked, setPicked] = useState(new Set());

  const sources = useMemo(() => [
    ...CAL.months.filter((m) => manifest.gscM.has(m.id)).map((m) => ({ v: gscKey("M", m.id), l: `GSC ${m.label}` })),
    ...CAL.weeks.filter((w) => manifest.gscW.has(w.id)).map((w) => ({ v: gscKey("W", w.id), l: `GSC ${w.id}` })),
    ...CAL.weeks.filter((w) => manifest.rank.has(w.id)).map((w) => ({ v: rankKey(w.id), l: `Ranks ${w.id}` })),
  ].reverse(), [manifest]);
  useEffect(() => { if (!src && sources.length) setSrc(sources[0].v); }, [sources, src]);
  useEffect(() => { if (src) ensure([src]); }, [src, ensure]);

  const candidates = useMemo(() => {
    const d = cache.current[src]; if (!d) return [];
    const map = src.startsWith("cph:rank:") ? d.pages : d;
    const q = pathQ.trim().toLowerCase();
    return Object.entries(map).filter(([k]) => !register[k] && (!q || k.includes(q)))
      .map(([k, v]) => ({ k, clicks: Array.isArray(v) ? v[0] : 0, impr: Array.isArray(v) ? v[1] : 0, kws: Array.isArray(v) ? null : v.n }))
      .sort((a, b) => (b.clicks - a.clicks) || (b.impr - a.impr) || ((b.kws || 0) - (a.kws || 0)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src, pathQ, register, ver]);
  useEffect(() => setPicked(new Set()), [src, pathQ]);

  const addPicked = async () => {
    const keys = [...picked];
    await mutateRegister((reg) => { keys.forEach((k) => { if (!reg[k]) reg[k] = { url: "https://" + k, writer: "", type: "", title: "", pub: "", pk: "", added: TODAY }; }); return reg; },
      `Started tracking ${keys.length} pages found in data`);
    flash(`Now tracking ${keys.length} more pages`); setPicked(new Set());
  };

  const deletePeriod = async (k, label) => {
    if (!confirm(`Delete imported data for ${label}? This can't be undone.`)) return;
    await S.del(k); delete cache.current[k]; await refreshManifest(); flash(`Deleted ${label}`);
  };
  const resetAll = async () => {
    if (!confirm("Delete ALL pages, imports, and settings for everyone using this tracker?")) return;
    if (prompt("Type DELETE to confirm") !== "DELETE") return;
    const keys = [...(await S.list("cph:"))];
    for (const k of keys) await S.del(k);
    await loadAll(); flash("Everything was deleted");
  };

  const imported = [
    ...CAL.months.filter((m) => manifest.gscM.has(m.id)).map((m) => [gscKey("M", m.id), `GSC month ${m.label}`]),
    ...CAL.weeks.filter((w) => manifest.gscW.has(w.id)).map((w) => [gscKey("W", w.id), `GSC cycle ${w.id}`]),
    ...CAL.weeks.filter((w) => manifest.rank.has(w.id)).map((w) => [rankKey(w.id), `Ranks ${w.id}`]),
    ...CAL.weeks.filter((w) => manifest.idx.has(w.id)).map((w) => [idxKey(w.id), `Index check ${w.id}`]),
  ];

  const card = { background: "#fff", border: `1px solid ${C.rule}` };
  return (
    <div className="grid gap-6" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(380px, 1fr))" }}>
      <section className="rounded p-4" style={card}>
        <h2 className="text-lg font-bold mb-1">Add pages from your data</h2>
        <div className="text-sm mb-3" style={{ color: C.muted }}>Every URL Google or Ahrefs/Semrush has seen that you aren't tracking yet. Filter by path, tick, add. The fastest way to load two years of content.</div>
        {sources.length === 0 ? <div className="text-sm" style={{ color: C.muted }}>Import a GSC or rank file first.</div> : (<>
          <div className="flex flex-wrap gap-2 mb-2">
            <Sel value={src} onChange={setSrc} options={sources} />
            <div style={{ width: 170 }}><Input value={pathQ} onChange={(e) => setPathQ(e.target.value)} placeholder="Path contains, e.g. /post/" /></div>
          </div>
          <div className="flex items-center gap-2 mb-2 text-sm">
            <button className="underline" onClick={() => setPicked(new Set(candidates.map((c) => c.k)))}>Select all {candidates.length}</button>
            <button className="underline" onClick={() => setPicked(new Set())}>None</button>
            <div className="flex-1" />
            <Btn small kind="primary" disabled={!picked.size} onClick={addPicked}><Plus size={13} /> Track {picked.size || ""} pages</Btn>
          </div>
          <div className="text-sm" style={{ maxHeight: 360, overflowY: "auto", borderTop: `1px solid ${C.soft}` }}>
            {candidates.slice(0, 500).map((c) => (
              <label key={c.k} className="flex items-center gap-2 py-1" style={{ borderBottom: `1px solid ${C.soft}` }}>
                <input type="checkbox" checked={picked.has(c.k)} onChange={() => setPicked((s) => { const n = new Set(s); n.has(c.k) ? n.delete(c.k) : n.add(c.k); return n; })} />
                <span className="truncate flex-1" title={c.k}>{c.k}</span>
                <span className="text-xs whitespace-nowrap" style={{ color: C.muted, ...NUM }}>{c.kws !== null ? `${c.kws} kws` : `${fmtInt(c.clicks)} clicks`}</span>
              </label>
            ))}
            {candidates.length > 500 && <div className="py-2 text-xs" style={{ color: C.muted }}>Showing 500 of {candidates.length}. “Select all” includes every match.</div>}
            {candidates.length === 0 && <div className="py-3" style={{ color: C.muted }}>No untracked URLs match.</div>}
          </div>
        </>)}
      </section>

      <section className="rounded p-4" style={card}>
        <h2 className="text-lg font-bold mb-3">Writers and content types</h2>
        <div className="flex flex-wrap gap-1.5 mb-2">
          {cfg.writers.map((w) => (
            <span key={w} className="text-sm px-2 py-1 rounded inline-flex items-center gap-1" style={{ background: C.soft }}>{w}
              <button aria-label={`Remove ${w}`} onClick={() => { if (confirm(`Remove ${w} from the writer list? Their pages keep the name until reassigned.`)) saveCfg({ ...cfg, writers: cfg.writers.filter((x) => x !== w) }); }}><X size={12} /></button>
            </span>))}
        </div>
        <div className="flex gap-2 mb-5">
          <Input value={newWriter} onChange={(e) => setNewWriter(e.target.value)} placeholder="New writer name" />
          <Btn onClick={() => { const n = newWriter.trim(); if (n && !cfg.writers.includes(n)) saveCfg({ ...cfg, writers: [...cfg.writers, n] }); setNewWriter(""); }}>Add</Btn>
        </div>
        <div className="flex flex-wrap gap-1.5 mb-2">
          {cfg.types.map((t) => (
            <span key={t} className="text-sm px-2 py-1 rounded inline-flex items-center gap-1" style={{ background: C.soft }}>{t}
              <button aria-label={`Remove ${t}`} onClick={() => saveCfg({ ...cfg, types: cfg.types.filter((x) => x !== t) })}><X size={12} /></button>
            </span>))}
        </div>
        <div className="flex gap-2 mb-5">
          <Input value={newType} onChange={(e) => setNewType(e.target.value)} placeholder="New content type" />
          <Btn onClick={() => { const n = newType.trim(); if (n && !cfg.types.includes(n)) saveCfg({ ...cfg, types: [...cfg.types, n] }); setNewType(""); }}>Add</Btn>
        </div>
        <h3 className="font-bold mb-1">Domains → project</h3>
        {Object.entries(cfg.domains).map(([h, p]) => (
          <div key={h} className="flex items-center justify-between text-sm py-1" style={{ borderBottom: `1px solid ${C.soft}` }}>
            <span>{h} → <b>{p}</b></span>
            <button aria-label={`Remove ${h}`} onClick={() => { const d = { ...cfg.domains }; delete d[h]; saveCfg({ ...cfg, domains: d }); }}><X size={12} /></button>
          </div>))}
        <div className="flex gap-2 mt-2">
          <Input value={dom.host} onChange={(e) => setDom({ ...dom, host: e.target.value })} placeholder="domain.com" />
          <Input value={dom.project} onChange={(e) => setDom({ ...dom, project: e.target.value })} placeholder="Project name" />
          <Btn onClick={() => { const h = normKey(dom.host).split("/")[0]; if (h && dom.project.trim()) saveCfg({ ...cfg, domains: { ...cfg.domains, [h]: dom.project.trim() } }); setDom({ host: "", project: "" }); }}>Add</Btn>
        </div>
      </section>

      <section className="rounded p-4" style={card}>
        <h2 className="text-lg font-bold mb-1">Imported data</h2>
        <div className="text-sm mb-2" style={{ color: C.muted }}>{Object.keys(register).length.toLocaleString()} pages tracked. Re-importing a period replaces it.</div>
        <div className="text-sm" style={{ maxHeight: 300, overflowY: "auto" }}>
          {imported.length === 0 && <div style={{ color: C.muted }}>Nothing imported yet.</div>}
          {imported.map(([k, l]) => (
            <div key={k} className="flex items-center justify-between py-1" style={{ borderBottom: `1px solid ${C.soft}` }}>
              <span>{l}</span><button className="text-xs underline" style={{ color: C.down }} onClick={() => deletePeriod(k, l)}>Delete</button>
            </div>))}
        </div>
        <div className="mt-6 pt-3" style={{ borderTop: `1px solid ${C.rule}` }}>
          <div className="text-sm mb-2" style={{ color: C.muted }}>Data here is shared: everyone who opens this tracker sees and edits the same pages and imports.</div>
          <Btn kind="danger" onClick={resetAll}><Trash2 size={14} /> Delete everything</Btn>
        </div>
      </section>
    </div>
  );
}
