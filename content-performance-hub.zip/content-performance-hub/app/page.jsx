"use client";
import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { installStorage } from "../lib/storage-client";

const Hub = dynamic(() => import("../components/ContentPerformanceHub"), { ssr: false });

export default function Page() {
  const [mode, setMode] = useState(null);

  useEffect(() => {
    installStorage().then(setMode);
  }, []);

  if (!mode) return <div style={{ padding: 24, fontFamily: "Arial, sans-serif", color: "#6B7178" }}>Connecting to shared storage…</div>;

  return (
    <>
      {mode === "local" && (
        <div style={{ background: "#FBE6EE", color: "#1C2126", padding: "8px 24px", fontFamily: "Arial, sans-serif", fontSize: 14 }}>
          Shared storage isn't connected, so data is saved in this browser only. Connect Upstash Redis in Vercel (see README) to share it with the team.
        </div>
      )}
      <Hub />
    </>
  );
}
