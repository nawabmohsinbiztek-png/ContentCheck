import { NextResponse } from "next/server";
import { Redis } from "@upstash/redis";

export const dynamic = "force-dynamic";

// Works with either env-var naming used by the Upstash integration on Vercel.
const url = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
const token = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;
const redis = url && token ? new Redis({ url, token, automaticDeserialization: false }) : null;

const NS = "cph-app:";          // namespace so other apps can share the database
const INDEX = NS + "__keys";     // set of all stored keys (avoids SCAN)
const KEY_RE = /^[^\s/\\'"]{1,200}$/;

const noDb = () => NextResponse.json({ error: "no-storage", hint: "Connect Upstash Redis to this Vercel project." }, { status: 503 });
const bad = (m) => NextResponse.json({ error: m }, { status: 400 });

export async function GET(req) {
  if (!redis) return noDb();
  const { searchParams } = new URL(req.url);
  if (searchParams.has("probe")) return NextResponse.json({ ok: true });
  if (searchParams.has("list")) {
    const prefix = searchParams.get("list") || "";
    const all = (await redis.smembers(INDEX)) || [];
    return NextResponse.json({ keys: all.filter((k) => k.startsWith(prefix)).sort() });
  }
  const k = searchParams.get("k");
  if (!k || !KEY_RE.test(k)) return bad("Invalid key");
  const value = await redis.get(NS + k);
  return NextResponse.json({ value: value ?? null });
}

export async function PUT(req) {
  if (!redis) return noDb();
  let body;
  try { body = await req.json(); } catch { return bad("Invalid JSON"); }
  const { k, v } = body || {};
  if (!k || !KEY_RE.test(k)) return bad("Invalid key");
  if (typeof v !== "string") return bad("Value must be a string");
  if (v.length > 4_000_000) return bad("Value too large even after compression. Filter the export and retry.");
  await redis.set(NS + k, v);
  await redis.sadd(INDEX, k);
  return NextResponse.json({ ok: true });
}

export async function DELETE(req) {
  if (!redis) return noDb();
  const k = new URL(req.url).searchParams.get("k");
  if (!k || !KEY_RE.test(k)) return bad("Invalid key");
  await redis.del(NS + k);
  await redis.srem(INDEX, k);
  return NextResponse.json({ ok: true });
}
