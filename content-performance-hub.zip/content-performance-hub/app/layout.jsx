import "./globals.css";

export const metadata = {
  title: "Content Performance — Print247 & CustomMylarBags",
  description: "Writer content performance from GSC, Ahrefs, and Semrush exports",
  robots: { index: false, follow: false },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
