# Content Performance Hub

Standalone version of the Print247 / CustomMylarBags content tracker. It is a Next.js app with a shared Upstash Redis database and a team password. It needs no Claude account.

## Deploy on Vercel (about 10 minutes, free tier is enough)

1. **Put the code on GitHub.** Create a private repo, upload this folder (without `node_modules`), and push.
   No GitHub? Run `npx vercel` inside this folder instead and follow the prompts.
2. **Import it in Vercel.** Vercel → Add New → Project → pick the repo → Deploy. The framework is detected as Next.js automatically.
3. **Add the database.** In the project, go to Storage → Create Database → Upstash for Redis (free plan) → Connect to this project. Vercel adds the connection variables for you.
4. **Set the team password.** Settings → Environment Variables:
   - `APP_PASSWORD` = the password your team will type
   - `APP_USER` = the username (optional; if you leave it out, any username works)
5. **Redeploy.** Deployments → ⋯ → Redeploy. Open the URL, log in, and share the URL and password with the writers.

Until the database is connected, the app still works but saves data in each person's browser only (a pink banner says so).

## Run on one computer instead

```
npm install
npm run dev
```
Open http://localhost:3000. Without the Upstash variables in a `.env.local` file, data stays in that browser.

## Moving data from the Claude version

In the Claude version, open Pages → CSV. Drop that CSV into Import data here: pages, writers, types, publish dates, and primary keywords carry over. Then re-import your GSC and Ahrefs/Semrush export files.

## Files

- `components/ContentPerformanceHub.jsx`: the whole app UI (same as the Claude version)
- `lib/storage-client.js`: saves data to the server, compressed, with a browser-only fallback
- `app/api/store/route.js`: the storage API backed by Upstash Redis
- `middleware.js`: team password (HTTP Basic Auth)
