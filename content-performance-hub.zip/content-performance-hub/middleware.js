import { NextResponse } from "next/server";

// Team password for the whole app (HTTP Basic Auth).
// Set APP_PASSWORD (and optionally APP_USER) in Vercel → Settings → Environment Variables.
export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"] };

export function middleware(req) {
  const pass = process.env.APP_PASSWORD;
  if (!pass) {
    if (process.env.NODE_ENV === "development") return NextResponse.next();
    return new NextResponse("Set APP_PASSWORD in Vercel → Settings → Environment Variables, then redeploy.", { status: 503 });
  }
  const auth = req.headers.get("authorization") || "";
  if (auth.startsWith("Basic ")) {
    try {
      const decoded = atob(auth.slice(6));
      const i = decoded.indexOf(":");
      const user = decoded.slice(0, i), pwd = decoded.slice(i + 1);
      if (pwd === pass && (!process.env.APP_USER || user === process.env.APP_USER)) return NextResponse.next();
    } catch { /* malformed header */ }
  }
  return new NextResponse("Authentication required", {
    status: 401,
    headers: { "WWW-Authenticate": 'Basic realm="Content Performance", charset="UTF-8"' },
  });
}
